# Bidiagonal SVD via TGK-rooted MR³

Fortran routines that compute the singular value decomposition of a real
bidiagonal matrix `B = U Σ Vᵀ` by running the tridiagonal **MR³ (MRRR)** algorithm
on the **Tridiagonal Golub–Kahan (TGK)** matrix of `B`, rooted at the TGK matrix
itself rather than at an `LDLᵀ` factorization.

The TGK matrix of an `n×n` bidiagonal `B` is the `2n×2n` symmetric tridiagonal with
zero diagonal whose off-diagonals interleave the entries of `B`
(`[d₁, e₁, d₂, e₂, …, d_n]`). Its eigenvalues are `±σᵢ` and its eigenvectors
interleave the left/right singular vectors, so the positive eigenpairs give the SVD.
By Kahan's theorem a zero-diagonal tridiagonal determines its eigenvalues to high
relative accuracy, which makes the TGK a relatively robust root for MR³.

See **[`DESIGN.md`](DESIGN.md)** for the full method and the map from each routine to
the relevant sections of the 1997 thesis (*A New O(n²) Algorithm for the Symmetric
Tridiagonal Eigenvalue/Eigenvector Problem*, Dhillon).

## Layout

| Path | Description |
|------|-------------|
| `dbdsvdmr3.f` | Top-level driver `DBDSVDMR3` (split → `DLASQ1` → TGK → tree → de-interleave); also contains the helper `DBSORT`. |
| `dbdtgk.f` | Builds the TGK off-diagonals and Gerschgorin intervals from `(d, e)`. |
| `dlar1v_tgk.f` | TGK-input variant of LAPACK `DLAR1V` (eigenvector / twisted factorization). |
| `dlarrf_tgk.f` | TGK-input variant of LAPACK `DLARRF` (child RRR; also does the §5.4 random relative perturbation). |
| `dlarrv_tgk.f` | Representation-tree driver: TGK matrix at the root, `LDLᵀ` (unmodified `stegr_ID`) below. |
| `stegr_ID/` | **Read-only** LAPACK MR³ reference (`dstegr`, `dlarre`, `dlarrv`, `dlar1v`, `dlarrf`, `dlarrb`, …). Not modified; the new code calls `DLARRB` from here and otherwise mirrors these routines. |
| `dev/` | Standalone test drivers (`test_*.f`) and NumPy validators (`validate_*.py`). |
| `DESIGN.md` | Method, derivations, and thesis cross-references. |

> **`stegr_ID/` is reference code and must not be edited.** All new logic lives in the
> top-level `*_tgk.f` / driver files.

## Driver interface

```fortran
CALL DBDSVDMR3( JOBZ, UPLO, N, D, E, S, U, LDU, VT, LDVT,
$               M, WORK, LWORK, IWORK, LIWORK, INFO )
```

- `JOBZ` = `'N'` (values only) or `'V'` (values + vectors)
- `UPLO` = `'U'` (upper) or `'L'` (lower) bidiagonal
- `D(N)`, `E(N)` — diagonal / off-diagonal of `B` (off-diagonal in `1..N-1`); overwritten
- `S(N)` — singular values, ascending; `U(LDU,N)` left vectors (columns); `VT(LDVT,N)` right vectors (rows)
- `LWORK ≥ 2*N*N + 34*N`, `LIWORK ≥ 20*N` (pass `-1` for a workspace query)

Range subsetting (`RANGE='I'/'V'`) is not yet implemented — all singular values are returned.

## Building

Requires a Fortran compiler (e.g. `gfortran`) and a LAPACK/BLAS providing
`DLASQ1`, `DSTEIN`, `DLAMCH`, `DLANST`, and the BLAS. The new code additionally
links `stegr_ID/dlarrb.o`.

Compile the library objects and the one reference routine the new code calls
(`gfortran -c` writes each `.o` into the current directory):

```sh
gfortran -c -O2 -std=legacy dbdtgk.f dlar1v_tgk.f dlarrf_tgk.f dlarrv_tgk.f dbdsvdmr3.f
gfortran -c -O2 -std=legacy stegr_ID/dlarrb.f      # -> dlarrb.o in the current dir
```

Link a test driver against those objects (`*.o` now includes `dlarrb.o`). macOS uses the
Accelerate framework for LAPACK/BLAS; on Linux use `-llapack -lblas`:

```sh
# macOS
gfortran -O2 -std=legacy dev/test_svd.f *.o -framework Accelerate -o test_svd
# Linux
gfortran -O2 -std=legacy dev/test_svd.f *.o -llapack -lblas -o test_svd
./test_svd
```

## Tests (`dev/`)

| File | Checks |
|------|--------|
| `test_svd.f` | Random bidiagonals `n = 2..55` vs `DGESVD` (residual, orthogonality, singular values). |
| `test_stcoll.f` | Reads an STCollection `B_*.dat` matrix (path as argv) and compares to `DGESVD`. |
| `test_glued.f` | Two glued copies of a graded bidiagonal (near-degenerate singular-value pairs). |
| `test_grow.f`, `test_specific.f` | `D=1, E=100` cases; high-relative-accuracy tiny singular values. |
| `test_split.f`, `test_trans.f` | `u`/`v` split vs `σ_min`; the balanced↔one-sided transition. |
| `test_ref_tgk.f` | Reference `DSTEGR` run on the TGK matrix (sanity comparison). |
| `validate_tgk.py`, `validate_pipeline.py`, `validate_cluster.py` | NumPy checks of the TGK recurrences, the end-to-end pipeline, and the cluster path. |

## Status

Passes a random test suite (`n = 2..55`) and the
[STCollection](https://github.com/oamarques/STCollection) bidiagonal matrices,
including graded, glued, split, zero-diagonal, and extreme-dynamic-range cases
(singular values down to `~10⁻¹⁷⁰`). Open items: elevated orthogonality on one large
matrix (`Kimura_429`), routing very tiny isolated singular values through an `LDLᵀ`
representation, and `RANGE='I'/'V'` subsetting.
