# Small glued-Wilkinson reproducers

Small matrices that reproduce the strong-glue orthogonality/residual
degradation (same mechanism as STCollection T_W21_g_1e+12, but tiny).

- `genglue.py`  -- generator. `gen(ncopies, glue, fname)` writes a
  symmetric-tridiagonal `.dat` of `ncopies` glued W21+ blocks (order
  21*ncopies) with off-diagonal `glue` at the junctions. Format matches
  test_chol_big (dim; then idx, diag, offdiag rows).
- `print_sv.f` -- forms L = chol(T - mu*I) exactly as the harness and
  prints all singular values of L (= positive eigenvalues of the root
  TGK) to 16 digits, with the relative gap to the next.
  Build: gfortran -O2 -std=legacy print_sv.f -llapack -lblas -o print_sv

Findings:
- 2 copies stays clean at ALL glue values (degradation needs >=3 copies:
  it is cluster MULTIPLICITY, not glue magnitude).
- W21x3_g1e+12 (order 63): orthU ~1.3e-9  -- smallest that degrades.
- W21x4_g1e+12 (order 84): orthU ~1.2e-5  -- strongest, still tiny.
  Its 84 singular values collapse to one ~78-fold bit-degenerate cluster
  near 1.00049875e6 (consecutive relgaps 0..1e-16), which the Sec.5.4
  perturbation must scramble.
