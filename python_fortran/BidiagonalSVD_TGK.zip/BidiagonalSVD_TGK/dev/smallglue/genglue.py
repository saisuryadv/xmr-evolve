def gen(ncopies, glue, fname):
    block = list(range(10,-1,-1)) + list(range(1,11))   # 10,9,...,0,...,10  (21)
    n = 21*ncopies
    diag = block*ncopies
    off = []
    for c in range(ncopies):
        off += [1.0]*20
        off.append(glue if c < ncopies-1 else 0.0)
    with open(fname,'w') as f:
        f.write("  %d\n" % n)
        for i in range(n):
            f.write("  %6d  %.15E  %.15E\n" % (i+1, float(diag[i]), off[i]))
for k in (2,3):
    for g in (1e6,1e9,1e12,1e15):
        gen(k, g, "/tmp/W21x%d_g%.0e.dat" % (k, g))
print("generated")
