      PROGRAM PRINT_SV
*     Reproduce L = chol(T - mu*I) exactly as test_chol_big / DBDSVDMR3
*     (mu=0 first, else a Gershgorin shift), then print all singular values
*     of L (= the positive eigenvalues of the root TGK) to 16 digits.
*     Tridiagonal file is command-line argument 1.
      IMPLICIT NONE
      INTEGER NMAX
      PARAMETER ( NMAX = 400 )
      DOUBLE PRECISION A(NMAX), B(NMAX), D(NMAX), E(NMAX), WK(4*NMAX)
      DOUBLE PRECISION AA, BB, MU, GMIN, PIV, RG, SMAX
      DOUBLE PRECISION CLTHR, G, RGI, ABMIN, ABMAX, RLMIN, RLMAX
      INTEGER N, I, IDX, INFO, JS, BS, BE, BEST, NZERO
      CHARACTER*120 FN
      CALL GET_COMMAND_ARGUMENT( 1, FN )
      OPEN( 10, FILE=FN, STATUS='OLD' )
      READ(10,*) N
      DO 10 I = 1, N
         READ(10,*) IDX, AA, BB
         A(I) = AA
         IF( I.LT.N ) B(I) = BB
   10 CONTINUE
      CLOSE(10)
      B(N) = 0.0D0
      GMIN = A(1) - ABS(B(1))
      DO 20 I = 2, N
         GMIN = MIN( GMIN, A(I) - ABS(B(I-1)) - ABS(B(I)) )
   20 CONTINUE
      MU = 0.0D0
   25 CONTINUE
      PIV = A(1) - MU
      IF( PIV.LE.0.0D0 ) GO TO 28
      D(1) = SQRT(PIV)
      DO 30 I = 1, N-1
         E(I) = B(I)/D(I)
         PIV = ( A(I+1) - MU ) - E(I)*E(I)
         IF( PIV.LE.0.0D0 ) GO TO 28
         D(I+1) = SQRT(PIV)
   30 CONTINUE
      GO TO 35
   28 CONTINUE
      IF( MU.EQ.0.0D0 .AND. GMIN.LE.0.0D0 ) THEN
         MU = GMIN - 1.0D-3*ABS(GMIN) - 1.0D-30
         GO TO 25
      END IF
      WRITE(*,*) 'Cholesky failed'
      STOP
   35 CONTINUE
      E(N) = 0.0D0
      WRITE(*,40) N, MU
   40 FORMAT(' N=',I4,'  mu=',ES23.15E3)
      CALL DLASQ1( N, D, E, WK, INFO )
      WRITE(*,*) 'DLASQ1 INFO=', INFO
      SMAX = D(1)
      WRITE(*,*) '  idx    sigma(16 digits)        relgap-to-next'
      DO 60 I = 1, N
         IF( I.LT.N ) THEN
            RG = ( D(I) - D(I+1) ) / SMAX
         ELSE
            RG = 0.0D0
         END IF
         WRITE(*,55) I, D(I), RG
   55    FORMAT(I5,2X,ES24.16E3,2X,ES12.4)
   60 CONTINUE
*
*     Locate the giant cluster = the longest run of consecutive sigma whose
*     internal relgaps (vs sigma_max) all stay below CLTHR, then report the
*     range of its consecutive gaps, absolute and relative (local, /sigma).
      CLTHR = 1.0D-3
      JS = 1
      BS = 1
      BE = 1
      BEST = 0
      DO 70 I = 1, N - 1
         IF( ( D(I) - D(I+1) ) / SMAX .GE. CLTHR ) THEN
            IF( I - JS .GT. BEST ) THEN
               BEST = I - JS
               BS = JS
               BE = I
            END IF
            JS = I + 1
         END IF
   70 CONTINUE
      IF( N - JS .GT. BEST ) THEN
         BS = JS
         BE = N
      END IF
      ABMIN = 1.0D300
      ABMAX = 0.0D0
      RLMIN = 1.0D300
      RLMAX = 0.0D0
      NZERO = 0
      DO 80 I = BS, BE - 1
         G = D(I) - D(I+1)
         RGI = G / D(I)
         IF( G.EQ.0.0D0 ) THEN
            NZERO = NZERO + 1
         ELSE
            ABMIN = MIN( ABMIN, G )
            RLMIN = MIN( RLMIN, RGI )
         END IF
         ABMAX = MAX( ABMAX, G )
         RLMAX = MAX( RLMAX, RGI )
   80 CONTINUE
      WRITE(*,*) ' '
      WRITE(*,90) BS, BE, BE-BS+1
   90 FORMAT(' GIANT CLUSTER: idx ',I4,' ..',I4,'   size',I4)
      WRITE(*,91) D(BE), D(BS)
   91 FORMAT('   value range : ',ES23.15E3,'  ..',ES23.15E3)
      WRITE(*,92) BE-BS, NZERO
   92 FORMAT('   gaps        : ',I4,'  (exact-zero gaps:',I4,')')
      WRITE(*,93) ABMIN, ABMAX
   93 FORMAT('   abs gap     : min(nonzero) ',ES12.4,'   max ',ES12.4)
      WRITE(*,94) RLMIN, RLMAX
   94 FORMAT('   rel gap     : min(nonzero) ',ES12.4,'   max ',ES12.4)
      STOP
      END
