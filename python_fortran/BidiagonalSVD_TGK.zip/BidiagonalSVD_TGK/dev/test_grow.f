      PROGRAM TEST_GROW
*
*     Test DBDSVDMR3 on the lower-bidiagonal matrix with 1's on the
*     diagonal and 100's on the off-diagonal, for N = 10, 20, 50, 100.
*     The smallest singular value is ~ 100^-(N-1), far below the absolute
*     accuracy of DGESVD, so the tiny tail is checked via det(B) = 1, i.e.
*     sum_i log10(sigma_i) must be 0.  Large singular values are compared
*     against DGESVD.
*
      IMPLICIT NONE
      INTEGER            NMAX, LWORK, LIWORK, LDU, LDVT, NTESTS
      PARAMETER          ( NMAX = 100, NTESTS = 4 )
      PARAMETER          ( LDU = NMAX, LDVT = NMAX )
      PARAMETER          ( LWORK = 4*NMAX*NMAX + 100*NMAX )
      PARAMETER          ( LIWORK = 30*NMAX )
*
      INTEGER            N, M, INFO, I, J, K, IT, NLIST( NTESTS )
      DOUBLE PRECISION   D( NMAX ), E( NMAX ), S( NMAX ),
     $                   U( LDU, NMAX ), VT( LDVT, NMAX ),
     $                   WORK( LWORK ), B( NMAX, NMAX ),
     $                   BSAV( NMAX, NMAX ), SREF( NMAX ),
     $                   UR( NMAX, NMAX ), VR( NMAX, NMAX )
      INTEGER            IWORK( LIWORK )
      DOUBLE PRECISION   RESID, ORTHU, ORTHV, TMP, LOGSUM, RELMAX, BNRM
      EXTERNAL           DBDSVDMR3, DGESVD
      INTRINSIC          ABS, MAX, LOG10
*
      NLIST( 1 ) = 10
      NLIST( 2 ) = 20
      NLIST( 3 ) = 50
      NLIST( 4 ) = 100
*
      DO 1000 IT = 1, NTESTS
         N = NLIST( IT )
*
         DO 10 I = 1, N
            D( I ) = 1.0D0
   10    CONTINUE
         DO 20 I = 1, N - 1
            E( I ) = 100.0D0
   20    CONTINUE
         E( N ) = 0.0D0
*
         DO 40 J = 1, N
            DO 30 I = 1, N
               B( I, J ) = 0.0D0
   30       CONTINUE
   40    CONTINUE
         DO 50 I = 1, N
            B( I, I ) = D( I )
   50    CONTINUE
         DO 60 I = 1, N - 1
            B( I+1, I ) = E( I )
   60    CONTINUE
         DO 80 J = 1, N
            DO 70 I = 1, N
               BSAV( I, J ) = B( I, J )
   70       CONTINUE
   80    CONTINUE
         BNRM = 0.0D0
         DO 85 I = 1, N
            BNRM = MAX( BNRM, ABS( D( I ) ) )
   85    CONTINUE
         BNRM = BNRM + 100.0D0
*
         CALL DGESVD( 'N', 'N', N, N, BSAV, NMAX, SREF, UR, NMAX,
     $                VR, NMAX, WORK, LWORK, INFO )
*
         CALL DBDSVDMR3( 'V', 'L', N, D, E, S, U, LDU, VT, LDVT, M,
     $                   WORK, LWORK, IWORK, LIWORK, INFO )
*
*        sum of log10(sigma): should be log10(det(B)) = 0.
*
         LOGSUM = 0.0D0
         DO 90 I = 1, M
            IF( S( I ).GT.0.0D0 ) LOGSUM = LOGSUM + LOG10( S( I ) )
   90    CONTINUE
*
*        max relative error of the DGESVD-resolvable singular values
*        (those above 1, which DGESVD computes accurately here).
*
         RELMAX = 0.0D0
         DO 95 I = 1, M
            IF( SREF( M-I+1 ).GT.1.0D0 ) THEN
               RELMAX = MAX( RELMAX,
     $                  ABS( S( I )-SREF( M-I+1 ) )/SREF( M-I+1 ) )
            END IF
   95    CONTINUE
*
*        residual ||B - U S V^T||_max.
*
         RESID = 0.0D0
         DO 120 I = 1, N
            DO 110 J = 1, N
               TMP = 0.0D0
               DO 100 K = 1, M
                  TMP = TMP + U( I, K )*S( K )*VT( K, J )
  100          CONTINUE
               RESID = MAX( RESID, ABS( TMP - B( I, J ) ) )
  110       CONTINUE
  120    CONTINUE
*
*        orthogonality.
*
         ORTHU = 0.0D0
         ORTHV = 0.0D0
         DO 150 I = 1, M
            DO 140 J = 1, M
               TMP = 0.0D0
               DO 130 K = 1, N
                  TMP = TMP + U( K, I )*U( K, J )
  130          CONTINUE
               IF( I.EQ.J ) TMP = TMP - 1.0D0
               ORTHU = MAX( ORTHU, ABS( TMP ) )
               TMP = 0.0D0
               DO 135 K = 1, N
                  TMP = TMP + VT( I, K )*VT( J, K )
  135          CONTINUE
               IF( I.EQ.J ) TMP = TMP - 1.0D0
               ORTHV = MAX( ORTHV, ABS( TMP ) )
  140       CONTINUE
  150    CONTINUE
*
         WRITE(*,200) N, INFO, M
  200    FORMAT( /, ' === N =', I4, '   INFO =', I3, '   M =', I4,
     $           ' ===' )
         WRITE(*,210) S( 1 ), S( M )
  210    FORMAT( '   sigma_min =', E14.6, '   sigma_max =', E14.6 )
         WRITE(*,220) LOGSUM
  220    FORMAT( '   sum log10(sigma) =', E13.5,
     $           '   (det check, target 0)' )
         IF( S( M ).GT.0.0D0 ) RESID = RESID / S( M )
         WRITE(*,230) RELMAX, RESID, ORTHU, ORTHV
  230    FORMAT( '   relerr(large sv)=', E11.4, '  rel.resid=', E11.4, /,
     $           '   orthU=', E11.4, '  orthV=', E11.4 )
 1000 CONTINUE
*
      STOP
      END
