      PROGRAM TEST_TRANS
      IMPLICIT NONE
      INTEGER NMAX, LDU, LDVT, LWORK, LIWORK
      PARAMETER ( NMAX = 26, LDU = NMAX, LDVT = NMAX )
      PARAMETER ( LWORK = 4*NMAX*NMAX+100*NMAX, LIWORK = 30*NMAX )
      INTEGER N, M, INFO, I, IWORK(LIWORK)
      DOUBLE PRECISION D(NMAX), E(NMAX), S(NMAX)
      DOUBLE PRECISION U(LDU,NMAX), VT(LDVT,NMAX), WORK(LWORK)
      DOUBLE PRECISION UN, VN
      EXTERNAL DBDSVDMR3
      INTRINSIC SQRT
      DO 1000 N = 20, 26
         DO I=1,N
            D(I)=1.0D0
         END DO
         DO I=1,N-1
            E(I)=100.0D0
         END DO
         E(N)=0.0D0
         CALL DBDSVDMR3('V','L',N,D,E,S,U,LDU,VT,LDVT,M,WORK,LWORK,
     $                  IWORK,LIWORK,INFO)
         UN=0.0D0
         VN=0.0D0
         DO I=1,N
            UN=UN+U(I,1)*U(I,1)
            VN=VN+VT(1,I)*VT(1,I)
         END DO
         WRITE(*,900) N, S(1), SQRT(UN), SQRT(VN)
  900    FORMAT('RESULT N=',I3,' sig_min=',E12.5,' ||u||=',E13.6,
     $          ' ||v||=',E13.6)
 1000 CONTINUE
      STOP
      END
