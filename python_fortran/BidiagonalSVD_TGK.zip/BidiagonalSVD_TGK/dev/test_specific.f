      PROGRAM TEST_SPECIFIC
*
*     Test DBDSVDMR3 on the lower-bidiagonal matrix with 1's on the
*     diagonal and 100's on the off-diagonal, order N=10.  Compare the
*     singular values against LAPACK DGESVD and report residual and
*     orthogonality.
*
      IMPLICIT NONE
      INTEGER            N, NMAX, LWORK, LIWORK, LDU, LDVT
      PARAMETER          ( N = 10, NMAX = N )
      PARAMETER          ( LDU = NMAX, LDVT = NMAX )
      PARAMETER          ( LWORK = 4*NMAX*NMAX + 100*NMAX )
      PARAMETER          ( LIWORK = 30*NMAX )
*
      INTEGER            M, INFO, I, J, K
      DOUBLE PRECISION   D( NMAX ), E( NMAX ), S( NMAX ),
     $                   U( LDU, NMAX ), VT( LDVT, NMAX ),
     $                   WORK( LWORK ), B( NMAX, NMAX ),
     $                   BSAV( NMAX, NMAX ), SREF( NMAX ),
     $                   UR( NMAX, NMAX ), VR( NMAX, NMAX )
      INTEGER            IWORK( LIWORK )
      DOUBLE PRECISION   RESID, ORTHU, ORTHV, TMP
      EXTERNAL           DBDSVDMR3, DGESVD
      INTRINSIC          ABS, MAX
*
*     Build B:  D(i) = 1,  E(i) = 100  (lower bidiagonal).
*
      DO 10 I = 1, N
         D( I ) = 1.0D0
   10 CONTINUE
      DO 20 I = 1, N - 1
         E( I ) = 100.0D0
   20 CONTINUE
      E( N ) = 0.0D0
*
      DO 40 J = 1, N
         DO 30 I = 1, N
            B( I, J ) = 0.0D0
   30    CONTINUE
   40 CONTINUE
      DO 50 I = 1, N
         B( I, I ) = D( I )
   50 CONTINUE
      DO 60 I = 1, N - 1
         B( I+1, I ) = E( I )
   60 CONTINUE
      DO 80 J = 1, N
         DO 70 I = 1, N
            BSAV( I, J ) = B( I, J )
   70    CONTINUE
   80 CONTINUE
*
*     Reference singular values via DGESVD (descending).
*
      CALL DGESVD( 'N', 'N', N, N, BSAV, NMAX, SREF, UR, NMAX,
     $             VR, NMAX, WORK, LWORK, INFO )
      WRITE(*,*) 'DGESVD INFO =', INFO
*
*     SVD via the new TGK-rooted MR^3 driver.
*
      CALL DBDSVDMR3( 'V', 'L', N, D, E, S, U, LDU, VT, LDVT, M,
     $                WORK, LWORK, IWORK, LIWORK, INFO )
      WRITE(*,*) 'DBDSVDMR3 INFO =', INFO, '  M =', M
*
      WRITE(*,*) ' '
      WRITE(*,*) '  i   sigma (MR3, ascending)   sigma (DGESVD, asc)'
      DO 90 I = 1, M
         WRITE(*,200) I, S( I ), SREF( M-I+1 )
  200    FORMAT( I4, 3X, E22.15, 3X, E22.15 )
   90 CONTINUE
*
*     Residual ||B - U S V^T||_max.
*
      RESID = 0.0D0
      DO 120 I = 1, N
         DO 110 J = 1, N
            TMP = 0.0D0
            DO 100 K = 1, M
               TMP = TMP + U( I, K )*S( K )*VT( K, J )
  100       CONTINUE
            RESID = MAX( RESID, ABS( TMP - B( I, J ) ) )
  110    CONTINUE
  120 CONTINUE
*
*     Orthogonality.
*
      ORTHU = 0.0D0
      ORTHV = 0.0D0
      DO 150 I = 1, M
         DO 140 J = 1, M
            TMP = 0.0D0
            DO 130 K = 1, N
               TMP = TMP + U( K, I )*U( K, J )
  130       CONTINUE
            IF( I.EQ.J ) TMP = TMP - 1.0D0
            ORTHU = MAX( ORTHU, ABS( TMP ) )
            TMP = 0.0D0
            DO 135 K = 1, N
               TMP = TMP + VT( I, K )*VT( J, K )
  135       CONTINUE
            IF( I.EQ.J ) TMP = TMP - 1.0D0
            ORTHV = MAX( ORTHV, ABS( TMP ) )
  140    CONTINUE
  150 CONTINUE
*
      WRITE(*,*) ' '
      IF( S( M ).GT.0.0D0 ) RESID = RESID / S( M )
      WRITE(*,210) RESID, ORTHU, ORTHV
  210 FORMAT( ' rel.resid=', E12.5, '  orthU=', E12.5,
     $        '  orthV=', E12.5 )
*
      STOP
      END
