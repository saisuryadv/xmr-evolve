      PROGRAM TEST_GLUED
*
*     Glue two copies of the lower-bidiagonal matrix (D=1, E=100, order
*     NB) with a small glue G between them, giving a single bidiagonal of
*     order N=2*NB with off-diagonals [100..100, G, 100..100].  Since
*     G >> eps*||B|| the matrix does NOT split, so the singular values
*     come in near-degenerate pairs -- the classic glued-matrix stress
*     test for the cluster/RRR machinery.  Compare to dense DGESVD.
*
      IMPLICIT NONE
      INTEGER NB, N, LDU, LDVT, LWORK, LIWORK
      PARAMETER ( NB = 10, N = 2*NB, LDU = N, LDVT = N )
      PARAMETER ( LWORK = 4*N*N+100*N, LIWORK = 30*N )
      DOUBLE PRECISION GLUE
      PARAMETER ( GLUE = 1.0D-5 )
      INTEGER M, INFO, I, J, K, IWORK(LIWORK)
      DOUBLE PRECISION D(N), E(N), S(N)
      DOUBLE PRECISION U(LDU,N), VT(LDVT,N), WORK(LWORK)
      DOUBLE PRECISION B(N,N), BSAV(N,N), SREF(N), UR(N,N), VR(N,N)
      DOUBLE PRECISION RESID, ORTHU, ORTHV, TMP, SDIFF
      EXTERNAL DBDSVDMR3, DGESVD
      INTRINSIC ABS, MAX
*
*     Build the glued bidiagonal.
*
      DO I=1,N
         D(I)=1.0D0
      END DO
      DO I=1,N-1
         E(I)=100.0D0
      END DO
      E(NB)=GLUE
      E(N)=0.0D0
*
      DO J=1,N
         DO I=1,N
            B(I,J)=0.0D0
         END DO
      END DO
      DO I=1,N
         B(I,I)=D(I)
      END DO
      DO I=1,N-1
         B(I+1,I)=E(I)
      END DO
      DO J=1,N
         DO I=1,N
            BSAV(I,J)=B(I,J)
         END DO
      END DO
*
      CALL DGESVD('N','N',N,N,BSAV,N,SREF,UR,N,VR,N,WORK,LWORK,INFO)
      WRITE(*,*) 'DGESVD INFO=',INFO
      CALL DBDSVDMR3('V','L',N,D,E,S,U,LDU,VT,LDVT,M,WORK,LWORK,
     $               IWORK,LIWORK,INFO)
      WRITE(*,*) 'DBDSVDMR3 INFO=',INFO,' M=',M
*
*     Singular values: MR3 ascending vs DGESVD descending.  Show pairs.
*
      WRITE(*,*) ' '
      WRITE(*,*) '  i   sigma (MR3, ascending)    sigma (DGESVD)'
      DO I=1,M
         WRITE(*,200) I, S(I), SREF(M-I+1)
      END DO
  200 FORMAT(I4,3X,E22.15,3X,E22.15)
*
      SDIFF=0.0D0
      DO I=1,M
         SDIFF=MAX(SDIFF,ABS(S(I)-SREF(M-I+1)))
      END DO
*
      RESID=0.0D0
      DO I=1,N
         DO J=1,N
            TMP=0.0D0
            DO K=1,M
               TMP=TMP+U(I,K)*S(K)*VT(K,J)
            END DO
            RESID=MAX(RESID,ABS(TMP-B(I,J)))
         END DO
      END DO
*
      ORTHU=0.0D0
      ORTHV=0.0D0
      DO I=1,M
         DO J=1,M
            TMP=0.0D0
            DO K=1,N
               TMP=TMP+U(K,I)*U(K,J)
            END DO
            IF(I.EQ.J) TMP=TMP-1.0D0
            ORTHU=MAX(ORTHU,ABS(TMP))
            TMP=0.0D0
            DO K=1,N
               TMP=TMP+VT(I,K)*VT(J,K)
            END DO
            IF(I.EQ.J) TMP=TMP-1.0D0
            ORTHV=MAX(ORTHV,ABS(TMP))
         END DO
      END DO
*
      WRITE(*,*) ' '
      IF( S(M).GT.0.0D0 ) RESID = RESID / S(M)
      WRITE(*,210) SDIFF, RESID, ORTHU, ORTHV
  210 FORMAT(' sdiff=',E12.5,' rel.resid=',E12.5,' orthU=',E12.5,
     $       ' orthV=',E12.5)
      STOP
      END
