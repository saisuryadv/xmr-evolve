      PROGRAM TEST_SVD
*
*     Driver test for DBDSVDMR3: random lower-bidiagonal B, compute the
*     SVD, and check ||B - U S V^T||, orthogonality of U and V, and the
*     singular values against LAPACK DGESVD on the dense matrix.
*
      IMPLICIT NONE
      INTEGER            NMAX, LWORK, LIWORK, LDU, LDVT
      PARAMETER          ( NMAX = 60 )
      PARAMETER          ( LDU = NMAX, LDVT = NMAX )
      PARAMETER          ( LWORK = 2*NMAX*NMAX + 100*NMAX )
      PARAMETER          ( LIWORK = 25*NMAX )
*
      INTEGER            N, M, INFO, I, J, K, ISEED( 4 )
      DOUBLE PRECISION   D( NMAX ), E( NMAX ), S( NMAX ),
     $                   U( LDU, NMAX ), VT( LDVT, NMAX ),
     $                   WORK( LWORK ), B( NMAX, NMAX ),
     $                   BSAV( NMAX, NMAX ), SREF( NMAX ),
     $                   UR( NMAX, NMAX ), VR( NMAX, NMAX )
      INTEGER            IWORK( LIWORK )
      DOUBLE PRECISION   RESID, ORTHU, ORTHV, SDIFF, TMP, BNRM, NEPS
      DOUBLE PRECISION   DLAMCH, DLANGE
      EXTERNAL           DBDSVDMR3, DLARNV, DGESVD, DLAMCH, DLANGE
      INTRINSIC          ABS, MAX, SQRT, DBLE
*
      ISEED( 1 ) = 13
      ISEED( 2 ) = 57
      ISEED( 3 ) = 101
      ISEED( 4 ) = 2025
*
      DO 1000 N = 2, 55
*
*        Random lower-bidiagonal B (diagonal D, subdiagonal E(1..N-1)).
*
         CALL DLARNV( 2, ISEED, N, D )
         CALL DLARNV( 2, ISEED, N-1, E )
         E( N ) = 0.0D0
*
*        Dense B and a saved copy for DGESVD.
*
         DO 20 J = 1, N
            DO 10 I = 1, N
               B( I, J ) = 0.0D0
   10       CONTINUE
   20    CONTINUE
         DO 30 I = 1, N
            B( I, I ) = D( I )
   30    CONTINUE
         DO 40 I = 1, N - 1
            B( I+1, I ) = E( I )
   40    CONTINUE
         DO 60 J = 1, N
            DO 50 I = 1, N
               BSAV( I, J ) = B( I, J )
   50       CONTINUE
   60    CONTINUE
         BNRM = DLANGE( 'M', N, N, B, NMAX, WORK )
*
*        Reference singular values via DGESVD (destroys BSAV).
*
         CALL DGESVD( 'N', 'N', N, N, BSAV, NMAX, SREF, UR, NMAX,
     $                VR, NMAX, WORK, LWORK, INFO )
         IF( INFO.NE.0 ) THEN
            WRITE(*,*) 'N=', N, ' DGESVD INFO=', INFO
            GO TO 1000
         END IF
*
*        SVD via the new TGK-rooted MR^3 driver.
*
         CALL DBDSVDMR3( 'V', 'L', N, D, E, S, U, LDU, VT, LDVT, M,
     $                   WORK, LWORK, IWORK, LIWORK, INFO )
         IF( INFO.NE.0 ) THEN
            WRITE(*,*) 'N=', N, ' DBDSVDMR3 INFO=', INFO
            GO TO 1000
         END IF
*
*        Residual ||B - U S V^T||_max  (S ascending; SREF descending).
*
         RESID = 0.0D0
         DO 90 I = 1, N
            DO 80 J = 1, N
               TMP = 0.0D0
               DO 70 K = 1, M
                  TMP = TMP + U( I, K )*S( K )*VT( K, J )
   70          CONTINUE
               RESID = MAX( RESID, ABS( TMP - B( I, J ) ) )
   80       CONTINUE
   90    CONTINUE
*
*        Orthogonality of U and V (V rows are in VT).
*
         ORTHU = 0.0D0
         ORTHV = 0.0D0
         DO 120 I = 1, M
            DO 110 J = 1, M
               TMP = 0.0D0
               BNRM = 0.0D0
               DO 100 K = 1, N
                  TMP = TMP + U( K, I )*U( K, J )
                  BNRM = BNRM + VT( I, K )*VT( J, K )
  100          CONTINUE
               IF( I.EQ.J ) THEN
                  TMP = TMP - 1.0D0
                  BNRM = BNRM - 1.0D0
               END IF
               ORTHU = MAX( ORTHU, ABS( TMP ) )
               ORTHV = MAX( ORTHV, ABS( BNRM ) )
  110       CONTINUE
  120    CONTINUE
*
*        Compare singular values (S ascending vs SREF descending).
*
         SDIFF = 0.0D0
         DO 130 I = 1, M
            SDIFF = MAX( SDIFF, ABS( S( I ) - SREF( M-I+1 ) ) )
  130    CONTINUE
*
         IF( S( M ).GT.0.0D0 ) RESID = RESID / S( M )
         WRITE(*,200) N, M, RESID, ORTHU, ORTHV, SDIFF
  200    FORMAT( 'N=', I3, ' M=', I3,
     $           '  rel.resid=', E10.3, '  orthU=', E10.3,
     $           '  orthV=', E10.3, '  sdiff=', E10.3 )
*        Multiples of n*eps (n=N, eps=DLAMCH('Precision')~2.22e-16):
         NEPS = DBLE( N )*DLAMCH( 'Precision' )
         WRITE(*,210) RESID/NEPS, ORTHU/NEPS, ORTHV/NEPS
  210    FORMAT( '       resid/(n.eps.||B||)=', F10.1,
     $           '  orthU/(n.eps)=', F10.1, '  orthV/(n.eps)=', F10.1 )
 1000 CONTINUE
*
      STOP
      END
