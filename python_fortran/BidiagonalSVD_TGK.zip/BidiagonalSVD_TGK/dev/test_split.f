      PROGRAM TEST_SPLIT
*
*     Probe the u/v split of the smallest singular vector as a function
*     of how small sigma_min is relative to eps*||B||.  B = lower
*     bidiagonal, D(i)=1, E(i)=EVAL.  sigma_min ~ EVAL^-(N-1).
*     For each case print sigma_min, eps*||B||, and ||u||,||v|| of the
*     smallest-sigma column (both should be 1 for a correct balanced
*     eigenvector).
*
      IMPLICIT NONE
      INTEGER NMAX, LWORK, LIWORK, LDU, LDVT
      PARAMETER ( NMAX = 30, LDU = NMAX, LDVT = NMAX )
      PARAMETER ( LWORK = 4*NMAX*NMAX+100*NMAX, LIWORK = 30*NMAX )
      INTEGER N, M, INFO, I, K, IT, IWORK(LIWORK)
      DOUBLE PRECISION D(NMAX), E(NMAX), S(NMAX)
      DOUBLE PRECISION U(LDU,NMAX), VT(LDVT,NMAX), WORK(LWORK)
      DOUBLE PRECISION EV, UN, VN, EPS, BN
      DOUBLE PRECISION DLAMCH
      EXTERNAL DBDSVDMR3, DLAMCH
      INTRINSIC SQRT
      INTEGER NL(4)
      DOUBLE PRECISION EL(4)
      NL(1)=6
      EL(1)=10.0D0
      NL(2)=10
      EL(2)=10.0D0
      NL(3)=6
      EL(3)=4.0D0
      NL(4)=8
      EL(4)=4.0D0
      EPS = DLAMCH('Precision')
      DO 1000 IT=1,4
         N = NL(IT)
         EV = EL(IT)
         DO I=1,N
            D(I)=1.0D0
         END DO
         DO I=1,N-1
            E(I)=EV
         END DO
         E(N)=0.0D0
         BN = 1.0D0 + EV
         CALL DBDSVDMR3('V','L',N,D,E,S,U,LDU,VT,LDVT,M,WORK,LWORK,
     $                  IWORK,LIWORK,INFO)
*        smallest singular value is S(1) (ascending)
         K = 1
         UN = 0.0D0
         VN = 0.0D0
         DO I=1,N
            UN = UN + U(I,K)*U(I,K)
            VN = VN + VT(K,I)*VT(K,I)
         END DO
         WRITE(*,900) N, EV, INFO, S(1), EPS*BN, SQRT(UN), SQRT(VN)
  900    FORMAT(' N=',I3,' E=',F6.1,' INFO=',I2,' sig_min=',E11.4,
     $          ' eps|B|=',E11.4,/,'      ||u||=',E13.6,
     $          ' ||v||=',E13.6)
 1000 CONTINUE
      STOP
      END
