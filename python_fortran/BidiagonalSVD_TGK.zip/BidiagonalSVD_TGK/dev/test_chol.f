      PROGRAM TEST_CHOL
*
*     Read a symmetric tridiagonal T (STCollection .dat format), form a
*     lower-bidiagonal Cholesky factor L of T - mu*I (mu <= 0 chosen so
*     the shifted matrix is positive definite; mu = 0 when T is already
*     PD), compute the SVD of L with DBDSVDMR3, and verify:
*       (a) singular values of L vs dense DGESVD(L);
*       (b) ||L - U S V^T|| and orthogonality of U, V;
*       (c) eigenvalue recovery: sigma_i^2 + mu vs eigenvalues of T
*           (DSTEV).  (sigma(L)^2 = eigenvalues of T - mu*I.)
*     Tridiagonal file passed as the first command-line argument.
*
      IMPLICIT NONE
      INTEGER NMAX, LWORK, LIWORK, LDU, LDVT
      PARAMETER ( NMAX = 200, LDU = NMAX, LDVT = NMAX )
      PARAMETER ( LWORK = 2*NMAX*NMAX + 200*NMAX, LIWORK = 25*NMAX )
      INTEGER N, M, INFO, I, J, K, IDX, IOS, IWORK(LIWORK)
      DOUBLE PRECISION A(NMAX), BO(NMAX), D(NMAX), E(NMAX), S(NMAX)
      DOUBLE PRECISION D0(NMAX), E0(NMAX), WE(NMAX), SREF(NMAX)
      DOUBLE PRECISION U(LDU,NMAX), VT(LDVT,NMAX), WORK(LWORK)
      DOUBLE PRECISION BL(NMAX,NMAX)
      DOUBLE PRECISION AA, BB, MU, GMIN, PIV, RESID, ORTHU, ORTHV
      DOUBLE PRECISION SDIFF, EVREL, TMP, LIJ, SMIN, SMAX
      CHARACTER*256 FNAME
      EXTERNAL DBDSVDMR3, DGESVD, DSTEV
      INTRINSIC ABS, MAX, MIN, SQRT
*
      CALL GET_COMMAND_ARGUMENT( 1, FNAME )
      OPEN( UNIT=10, FILE=FNAME, STATUS='OLD', IOSTAT=IOS )
      IF( IOS.NE.0 ) THEN
         WRITE(*,*) 'cannot open ', FNAME
         STOP
      END IF
      READ(10,*) N
      DO 10 I = 1, N
         READ(10,*) IDX, AA, BB
         A( I ) = AA
         BO( I ) = BB
   10 CONTINUE
      CLOSE(10)
      BO( N ) = 0.0D0
*
*     Gershgorin lower bound; shift so T - mu*I is positive definite.
*
      GMIN = A( 1 ) - ABS( BO( 1 ) )
      DO 20 I = 2, N
         GMIN = MIN( GMIN, A( I ) - ABS( BO( I-1 ) ) - ABS( BO( I ) ) )
   20 CONTINUE
*     Cholesky of T - mu*I = L L^T, L lower bidiagonal (diag D, subdiag E).
*     Try mu = 0 first (Gershgorin is often pessimistically negative for a
*     PD matrix); only shift if a non-positive pivot actually appears.
*
      MU = 0.0D0
   25 CONTINUE
      PIV = A( 1 ) - MU
      IF( PIV.LE.0.0D0 ) GO TO 28
      D( 1 ) = SQRT( PIV )
      DO 30 I = 1, N - 1
         E( I ) = BO( I ) / D( I )
         PIV = ( A( I+1 ) - MU ) - E( I )*E( I )
         IF( PIV.LE.0.0D0 ) GO TO 28
         D( I+1 ) = SQRT( PIV )
   30 CONTINUE
      GO TO 35
   28 CONTINUE
      IF( MU.EQ.0.0D0 .AND. GMIN.LE.0.0D0 ) THEN
         MU = GMIN - 1.0D-3*ABS( GMIN ) - 1.0D-30
         GO TO 25
      END IF
      WRITE(*,*) 'Cholesky non-positive pivot even after shift'
      STOP
   35 CONTINUE
      E( N ) = 0.0D0
*
*     Save L and build dense L for DGESVD / eigenvalue reference.
*
      DO 40 I = 1, N
         D0( I ) = D( I )
         E0( I ) = E( I )
   40 CONTINUE
      DO 60 J = 1, N
         DO 50 I = 1, N
            BL( I, J ) = 0.0D0
   50    CONTINUE
   60 CONTINUE
      DO 70 I = 1, N
         BL( I, I ) = D0( I )
   70 CONTINUE
      DO 80 I = 1, N - 1
         BL( I+1, I ) = E0( I )
   80 CONTINUE
*
*     Reference singular values of L (dense DGESVD; destroys BL).
*
      CALL DGESVD( 'N', 'N', N, N, BL, NMAX, SREF, U, LDU, VT, LDVT,
     $             WORK, LWORK, INFO )
*
*     Reference eigenvalues of T via DSTEV (ascending).
*
      DO 90 I = 1, N
         WE( I ) = A( I )
   90 CONTINUE
      DO 95 I = 1, N - 1
         WORK( I ) = BO( I )
   95 CONTINUE
      CALL DSTEV( 'N', N, WE, WORK, U, LDU, WORK(N+1), INFO )
*
*     SVD of L by the TGK-rooted MR^3 driver (overwrites D,E).
*
      CALL DBDSVDMR3( 'V', 'L', N, D, E, S, U, LDU, VT, LDVT, M, WORK,
     $                LWORK, IWORK, LIWORK, INFO )
      WRITE(*,200) N, INFO, M, MU
  200 FORMAT( ' N=', I4, ' INFO=', I3, ' M=', I4, ' shift mu=', E12.5 )
*
      SMIN = 1.0D30
      SMAX = 0.0D0
      DO 100 I = 1, M
         SMAX = MAX( SMAX, S( I ) )
         IF( S( I ).GT.0.0D0 ) SMIN = MIN( SMIN, S( I ) )
  100 CONTINUE
*
*     (a) singular values vs DGESVD (S ascending, SREF descending).
*
      SDIFF = 0.0D0
      DO 110 I = 1, M
         SDIFF = MAX( SDIFF, ABS( S( I )-SREF( M-I+1 ) ) )
  110 CONTINUE
*
*     (c) eigenvalue recovery: sigma_i^2 + mu vs eig(T) (both ascending),
*         relative to ||T|| ~ max|eig|.
*
      TMP = MAX( ABS( WE( 1 ) ), ABS( WE( N ) ) )
      EVREL = 0.0D0
      DO 120 I = 1, M
         EVREL = MAX( EVREL, ABS( S( I )*S( I )+MU - WE( I ) ) )
  120 CONTINUE
      IF( TMP.GT.0.0D0 ) EVREL = EVREL / TMP
*
*     (b) residual ||L - U S V^T|| and orthogonality.
*
      RESID = 0.0D0
      DO 150 I = 1, N
         DO 140 J = 1, N
            TMP = 0.0D0
            DO 130 K = 1, M
               TMP = TMP + U( I, K )*S( K )*VT( K, J )
  130       CONTINUE
            LIJ = 0.0D0
            IF( I.EQ.J ) LIJ = D0( I )
            IF( I.EQ.J+1 ) LIJ = E0( J )
            RESID = MAX( RESID, ABS( TMP-LIJ ) )
  140    CONTINUE
  150 CONTINUE
*
      ORTHU = 0.0D0
      ORTHV = 0.0D0
      DO 180 I = 1, M
         DO 170 J = 1, M
            TMP = 0.0D0
            DO 160 K = 1, N
               TMP = TMP + U( K, I )*U( K, J )
  160       CONTINUE
            IF( I.EQ.J ) TMP = TMP - 1.0D0
            ORTHU = MAX( ORTHU, ABS( TMP ) )
            TMP = 0.0D0
            DO 165 K = 1, N
               TMP = TMP + VT( I, K )*VT( J, K )
  165       CONTINUE
            IF( I.EQ.J ) TMP = TMP - 1.0D0
            ORTHV = MAX( ORTHV, ABS( TMP ) )
  170    CONTINUE
  180 CONTINUE
*
      WRITE(*,210) SMIN, SMAX
  210 FORMAT( '   sigma_min=', E13.6, '  sigma_max=', E13.6 )
      WRITE(*,220) SDIFF, EVREL
  220 FORMAT( '   |S-DGESVD|=', E11.4, '   rel |sigma^2+mu - eig(T)|=',
     $        E11.4 )
      IF( SMAX.GT.0.0D0 ) RESID = RESID / SMAX
      WRITE(*,230) RESID, ORTHU, ORTHV
  230 FORMAT( '   rel.resid(L)=', E11.4, '  orthU=', E11.4,
     $        '  orthV=', E11.4 )
      STOP
      END
