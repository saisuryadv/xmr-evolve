#!/usr/bin/env python3
"""Localize the failure: does the cluster / child-representation path of the
algorithm reproduce orthonormal singular vectors?  Mimics DLARRV_TGK at the
TGK root: form child LDL^T = T_GK - sigma I via the dlarrf_tgk recurrence
(picking the cluster end with least element growth), then compute each
positive eigenvector from the child via an LDL^T twisted factorization
(the REP='L' path), and check.  If this passes, the bug is Fortran-specific
(indexing/workspace), not the algorithm."""
import numpy as np
from validate_tgk import tgk_arrays, tgk_dense, stationary, progressive

np.random.seed(2)


def child_ldlt(diag, beta, sigma):
    """dlarrf_tgk REP='T': child L D L^T = T - sigma I from tridiagonal."""
    return stationary(diag, beta, sigma)        # (D+, L+)


def ldlt_dense(dplus, lplus):
    m = len(dplus)
    L = np.eye(m)
    for i in range(m - 1):
        L[i + 1, i] = lplus[i]
    return L, np.diag(dplus)


def stat_ldlt(dplus, lplus, tau):
    """Stationary transform of (L D L^T) - tau I, differential form, as in
    DLAR1V REP='L'.  Returns Dp (pivots) and Lp (multipliers)."""
    m = len(dplus)
    d = dplus
    l = np.zeros(m)
    l[:m-1] = lplus
    ld = l * d                # L(i) D(i)
    lld = ld * l              # L(i)^2 D(i)
    Dp = np.empty(m)
    Lp = np.empty(m - 1)
    s = -tau
    for i in range(m - 1):
        Dp[i] = d[i] + s
        Lp[i] = ld[i] / Dp[i]
        s = s * Lp[i] * l[i] - tau
    Dp[m-1] = d[m-1] + s
    return Dp, Lp


def prog_ldlt(dplus, lplus, tau):
    m = len(dplus)
    d = dplus
    l = np.zeros(m); l[:m-1] = lplus
    lld = l * l * d
    Dm = np.empty(m)
    Um = np.empty(m - 1)
    p = d[m-1] - tau
    Dm[m-1] = p
    for i in range(m - 2, -1, -1):
        dminus = lld[i] + p
        t = d[i] / dminus
        Um[i] = l[i] * t
        p = p * t - tau
        Dm[i] = p
    return Dm, Um


def eigvec_from_ldlt(dplus, lplus, tau):
    """Twisted-factorization eigenvector of (L D L^T) for shift tau (REP='L')."""
    m = len(dplus)
    Dp, Lp = stat_ldlt(dplus, lplus, tau)
    Dm, Um = prog_ldlt(dplus, lplus, tau)
    # gamma_k = Dp_pivot(k) + Dm_pivot(k) - (dplus(k) - tau); reuse direct form
    d = dplus
    gam = np.empty(m)
    # reconstruct stationary/progressive pivots directly for gamma:
    # use the same identity as the tridiagonal case but on the LDL^T matrix
    A = ldlt_dense(dplus, lplus)
    M = A[0] @ A[1] @ A[0].T
    g = 1.0 / np.diag(np.linalg.inv(M - tau * np.eye(m)))
    r = int(np.argmin(np.abs(g)))
    z = np.zeros(m); z[r] = 1.0
    for i in range(r - 1, -1, -1):
        z[i] = -Lp[i] * z[i + 1]
    for i in range(r, m - 1):
        z[i + 1] = -Um[i] * z[i]
    return z / np.linalg.norm(z)


def run(n):
    d = np.random.randn(n)
    e = np.random.randn(n - 1)
    diag, beta = tgk_arrays(d, e)
    sv = np.sort(np.linalg.svd(np.diag(d) + np.diag(e, -1), compute_uv=False))
    # treat ALL positives as one cluster (worst case): form a child at the
    # left end and compute every positive eigenvector from the child.
    relgap = np.min(np.diff(sv) / sv[1:]) if n > 1 else 1.0
    # pick shift = left end with least element growth (mimic dlarrf_tgk)
    cand = []
    for sig in (sv[0], sv[-1]):
        Dp, Lp = child_ldlt(diag, beta, sig)
        cand.append((np.max(np.abs(Dp)), sig, Dp, Lp))
    cand.sort()
    _, sigma, Dp, Lp = cand[0]
    U = np.empty((n, n)); V = np.empty((n, n))
    for j in range(n):
        z = eigvec_from_ldlt(Dp, Lp, sv[j] - sigma)
        U[:, j] = np.sqrt(2) * z[0::2]
        V[:, j] = np.sqrt(2) * z[1::2]
    B = np.diag(d) + np.diag(e, -1)
    resid = np.max(np.abs(U @ np.diag(sv) @ V.T - B))
    orthu = np.max(np.abs(U.T @ U - np.eye(n)))
    print(f"n={n:3d}  min_relgap={relgap:.2e}  resid={resid:.2e}  "
          f"orthU={orthu:.2e}  {'PASS' if max(resid,orthu)<1e-6 else 'FAIL'}")


if __name__ == "__main__":
    for n in (5, 8, 11, 12, 17, 20, 25):
        run(n)
