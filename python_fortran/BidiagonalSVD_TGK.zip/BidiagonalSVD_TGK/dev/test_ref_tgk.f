      PROGRAM TEST_REF_TGK
*
*     Run the ORIGINAL stegr_ID DSTEGR on the TGK matrix of the
*     bidiagonal (1 on diag, 100 off-diag), n=50  =>  TGK order 100.
*     Check eigenvector orthogonality.  This isolates whether the
*     orthogonality loss is in the TGK rooting (our code) or shared by
*     the reference MR^3 on this clustered TGK spectrum.
*
      IMPLICIT NONE
      INTEGER            NB, MT, LWORK, LIWORK
      PARAMETER          ( NB = 50, MT = 2*NB )
      PARAMETER          ( LWORK = 20*MT, LIWORK = 12*MT )
      INTEGER            M, INFO, I, J, K, ISUPPZ( 2*MT )
      INTEGER            IWORK( LIWORK )
      DOUBLE PRECISION   DT( MT ), ET( MT ), W( MT ), Z( MT, MT ),
     $                   WORK( LWORK )
      DOUBLE PRECISION   ORTH, TMP
      EXTERNAL           DSTEGR
      INTRINSIC          ABS, MAX, MOD
*
*     TGK: zero diagonal; off-diagonals interleave 1 (diag of B) and
*     100 (off-diag of B):  ET(odd)=1, ET(even)=100.
*
      DO 10 I = 1, MT
         DT( I ) = 0.0D0
   10 CONTINUE
      DO 20 I = 1, MT - 1
         IF( MOD( I, 2 ).EQ.1 ) THEN
            ET( I ) = 1.0D0
         ELSE
            ET( I ) = 100.0D0
         END IF
   20 CONTINUE
      ET( MT ) = 0.0D0
*
      CALL DSTEGR( 'V', 'A', MT, DT, ET, 0.0D0, 0.0D0, 1, MT, 0.0D0,
     $             M, W, Z, MT, ISUPPZ, WORK, LWORK, IWORK, LIWORK,
     $             INFO )
      WRITE(*,*) 'DSTEGR INFO =', INFO, '  M =', M
      WRITE(*,*) 'eigenvalue range: ', W(1), ' ... ', W(M)
*
*     Orthogonality of all computed eigenvectors.
*
      ORTH = 0.0D0
      DO 50 I = 1, M
         DO 40 J = 1, M
            TMP = 0.0D0
            DO 30 K = 1, MT
               TMP = TMP + Z( K, I )*Z( K, J )
   30       CONTINUE
            IF( I.EQ.J ) TMP = TMP - 1.0D0
            ORTH = MAX( ORTH, ABS( TMP ) )
   40    CONTINUE
   50 CONTINUE
      WRITE(*,210) ORTH
  210 FORMAT( ' reference DSTEGR  ||Z^T Z - I||_max =', E12.5 )
*
*     For the eigenvector of the smallest-magnitude POSITIVE eigenvalue
*     (= smallest singular value), report the odd/even split:
*        u <- odd entries, v <- even entries.  A genuine +sigma_1
*        eigenvector splits 50/50 (||odd|| = ||even|| = 1/sqrt(2)).
*
      K = 0
      TMP = 1.0D30
      DO 60 I = 1, M
         IF( W( I ).GT.0.0D0 .AND. W( I ).LT.TMP ) THEN
            TMP = W( I )
            K = I
         END IF
   60 CONTINUE
      ORTH = 0.0D0
      TMP = 0.0D0
      DO 70 I = 1, MT
         IF( MOD( I, 2 ).EQ.1 ) THEN
            ORTH = ORTH + Z( I, K )*Z( I, K )
         ELSE
            TMP = TMP + Z( I, K )*Z( I, K )
         END IF
   70 CONTINUE
      WRITE(*,220) K, W( K ), SQRT( ORTH ), SQRT( TMP )
  220 FORMAT( ' smallest +sigma: col', I4, ' value=', E12.5, /,
     $        '   ||odd(z)|| (->u) =', E13.6,
     $        '   ||even(z)|| (->v) =', E13.6 )
*
      STOP
      END
