#!/usr/bin/env python3
"""Numerical validation of the TGK-path recurrences used in dlar1v_tgk.f /
dlarrf_tgk.f.  There is no Fortran compiler on the dev machine, so this script
mirrors the exact arithmetic of the REP='T' code paths in double precision and
checks them against dense linear algebra.  It is a development aid only and is
NOT part of the Fortran library (and does not touch stegr_ID).

Checks:
  1. positive eigenvalues of the TGK matrix == singular values of B.
  2. gamma_k = D+(k) + D-(k) - (diag(k)-sigma)  equals  1 / inv(T-sigma I)[k,k].
  3. the twisted r-th column (argmin|gamma_k|) is an accurate eigenvector of
     T_GK for sigma ~ +sigma_i, and its interleaved entries reproduce u_i, v_i.
  4. dlarrf_tgk child: D+ from the tridiagonal recurrence reconstructs T_GK-sigma I.
"""
import numpy as np

np.random.seed(0)


def tgk_arrays(d, e):
    """Return (diag, beta) of the 2n x 2n TGK matrix for lower-bidiagonal B
    with diagonal d (len n) and off-diagonal e (len n-1)."""
    n = len(d)
    beta = np.empty(2 * n - 1)
    beta[0::2] = d                # d_1, d_2, ..., d_n   at even positions
    beta[1::2] = e                # e_1, ..., e_{n-1}     at odd positions
    diag = np.zeros(2 * n)
    return diag, beta


def tgk_dense(diag, beta):
    m = len(diag)
    T = np.diag(diag).astype(float)
    for i in range(m - 1):
        T[i, i + 1] = beta[i]
        T[i + 1, i] = beta[i]
    return T


def stationary(diag, beta, sigma):
    """Direct dstqds on the tridiagonal: returns D+ (len m) and L+ (len m-1)."""
    m = len(diag)
    dplus = np.empty(m)
    lplus = np.empty(m - 1)
    dplus[0] = diag[0] - sigma
    for i in range(m - 1):
        lplus[i] = beta[i] / dplus[i]
        dplus[i + 1] = diag[i + 1] - sigma - lplus[i] * beta[i]
    return dplus, lplus


def progressive(diag, beta, sigma):
    """Direct dqds: returns D- (len m) and U- (len m-1)."""
    m = len(diag)
    dminus = np.empty(m)
    uminus = np.empty(m - 1)
    dminus[-1] = diag[-1] - sigma
    for i in range(m - 2, -1, -1):
        uminus[i] = beta[i] / dminus[i + 1]
        dminus[i] = diag[i] - sigma - uminus[i] * beta[i]
    return dminus, uminus


def gammas(diag, beta, sigma):
    dplus, _ = stationary(diag, beta, sigma)
    dminus, _ = progressive(diag, beta, sigma)
    return dplus + dminus - (diag - sigma)      # gamma_k, thesis eq 3.1.12


def twisted_column(diag, beta, sigma, r):
    """Solve (T - sigma I) z = gamma_r e_r with z[r]=1 (0-based r)."""
    m = len(diag)
    dplus, lplus = stationary(diag, beta, sigma)
    dminus, uminus = progressive(diag, beta, sigma)
    z = np.zeros(m)
    z[r] = 1.0
    for i in range(r - 1, -1, -1):
        z[i] = -lplus[i] * z[i + 1]
    for i in range(r, m - 1):
        z[i + 1] = -uminus[i] * z[i]
    return z


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    return ok


def run_one(n):
    print(f"n = {n}")
    d = np.random.randn(n)
    e = np.random.randn(n - 1)
    diag, beta = tgk_arrays(d, e)
    T = tgk_dense(diag, beta)
    m = 2 * n

    # 1. positive eigenvalues == singular values
    evals, evecs = np.linalg.eigh(T)
    svals = np.linalg.svd(np.diag(d) + np.diag(e, -1), compute_uv=False)
    pos = np.sort(evals[evals > 0])
    ok1 = check("pos eig == sing vals",
                np.allclose(pos, np.sort(svals), atol=1e-10),
                f"max diff {np.max(np.abs(pos - np.sort(svals))):.2e}")

    # 2. gamma_k == 1 / inv(T - sigma I)[k,k]
    sigma = pos[len(pos) // 2] * (1 + 1e-9)     # near a positive eigenvalue
    g = gammas(diag, beta, sigma)
    inv_diag = np.diag(np.linalg.inv(T - sigma * np.eye(m)))
    ok2 = check("gamma_k == 1/inv_diag",
                np.allclose(1.0 / g, inv_diag, rtol=1e-6),
                f"max rel {np.max(np.abs(1.0/g - inv_diag)/np.abs(inv_diag)):.2e}")

    # 3. twisted column at argmin|gamma| is the eigenvector
    r = int(np.argmin(np.abs(g)))
    z = twisted_column(diag, beta, sigma, r)
    z /= np.linalg.norm(z)
    k = int(np.argmin(np.abs(evals - sigma)))
    target = evecs[:, k]
    if np.dot(z, target) < 0:
        target = -target
    ok3 = check("twisted col == eigvec",
                np.allclose(z, target, atol=1e-7),
                f"angle {np.arccos(np.clip(abs(np.dot(z,target)),0,1)):.2e} rad")

    # interleaved entries reconstruct u_i (even idx) and v_i (odd idx), up to
    # the 1/sqrt(2) Golub-Kahan scaling
    u = z[0::2] * np.sqrt(2)
    v = z[1::2] * np.sqrt(2)
    ok3b = check("|u|,|v| are unit",
                 np.isclose(np.linalg.norm(u), 1, atol=1e-6) and
                 np.isclose(np.linalg.norm(v), 1, atol=1e-6),
                 f"|u|={np.linalg.norm(u):.4f} |v|={np.linalg.norm(v):.4f}")

    # 4. dlarrf_tgk child reconstructs T - sigma I
    dplus, lplus = stationary(diag, beta, sigma)
    Lmat = np.eye(m)
    for i in range(m - 1):
        Lmat[i + 1, i] = lplus[i]
    recon = Lmat @ np.diag(dplus) @ Lmat.T
    ok4 = check("L+ D+ L+^T == T - sigma I",
                np.allclose(recon, T - sigma * np.eye(m), atol=1e-8),
                f"max diff {np.max(np.abs(recon-(T-sigma*np.eye(m)))):.2e}")

    return all([ok1, ok2, ok3, ok3b, ok4])


if __name__ == "__main__":
    allok = True
    for n in (3, 5, 8, 13):
        allok &= run_one(n)
        print()
    print("ALL PASS" if allok else "SOME FAILED")
