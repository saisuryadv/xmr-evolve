#!/usr/bin/env python3
"""End-to-end validation of the DBDSVDMR3 orchestration logic (split,
positive-eigenvalue indexing, and the u/v de-interleave) in NumPy.  This
mirrors the Fortran driver's bookkeeping; it does NOT compile the Fortran.
Ground-truth TGK eigenvectors come from numpy.eigh (the Fortran obtains the
same vectors via MR^3, validated separately in validate_tgk.py)."""
import numpy as np
from validate_tgk import tgk_arrays, tgk_dense

np.random.seed(1)


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  {detail}" if detail else ""))
    return ok


def positive_index_check(nb):
    """Confirm the j-th positive eigenvalue is at ascending position nb+j."""
    d = np.random.randn(nb)
    e = np.random.randn(nb - 1)
    diag, beta = tgk_arrays(d, e)
    ev = np.sort(np.linalg.eigvalsh(tgk_dense(diag, beta)))
    pos = ev[nb:]                 # positions nb+1..2nb (0-based nb..2nb-1)
    sv = np.sort(np.linalg.svd(np.diag(d) + np.diag(e, -1),
                               compute_uv=False))
    return check(f"INDEXW: positive block at nb+1..2nb (nb={nb})",
                 np.allclose(pos, sv, atol=1e-10))


def deinterleave_svd(d, e):
    """Emulate the driver: TGK -> positive eigenpairs -> de-interleave."""
    n = len(d)
    diag, beta = tgk_arrays(d, e)
    w, Zev = np.linalg.eigh(tgk_dense(diag, beta))
    # take the n positive eigenpairs, ascending
    idx = np.argsort(w)[n:]
    S = w[idx]
    Z = Zev[:, idx]
    U = np.empty((n, n))
    V = np.empty((n, n))
    for k in range(n):
        z = Z[:, k]
        U[:, k] = np.sqrt(2) * z[0::2]   # odd 1-based positions -> u
        V[:, k] = np.sqrt(2) * z[1::2]   # even 1-based positions -> v
    return S, U, V


def run(n_blocks):
    """Build a block-diagonal bidiagonal (a zero off-diagonal between
    blocks) and check the full reconstruction."""
    sizes = [np.random.randint(2, 6) for _ in range(n_blocks)]
    n = sum(sizes)
    d = np.random.randn(n)
    e = np.random.randn(n - 1)
    # zero out off-diagonals at block boundaries to force splits
    pos = 0
    for s in sizes[:-1]:
        pos += s
        e[pos - 1] = 0.0
    print(f"blocks={sizes} (n={n})")

    B = np.diag(d) + np.diag(e, -1)         # lower bidiagonal
    S, U, V = deinterleave_svd(d, e)

    ok1 = check("B == U S V^T",
                np.allclose(U @ np.diag(S) @ V.T, B, atol=1e-9),
                f"max diff {np.max(np.abs(U@np.diag(S)@V.T - B)):.2e}")
    ok2 = check("U^T U == I",
                np.allclose(U.T @ U, np.eye(n), atol=1e-8),
                f"max off {np.max(np.abs(U.T@U - np.eye(n))):.2e}")
    ok3 = check("V^T V == I",
                np.allclose(V.T @ V, np.eye(n), atol=1e-8),
                f"max off {np.max(np.abs(V.T@V - np.eye(n))):.2e}")
    ok4 = check("S == numpy svd",
                np.allclose(np.sort(S), np.sort(np.linalg.svd(B, compute_uv=False)),
                            atol=1e-10))
    return all([ok1, ok2, ok3, ok4])


if __name__ == "__main__":
    allok = True
    for nb in (2, 4, 7):
        allok &= positive_index_check(nb)
    print()
    for nbk in (1, 2, 3):
        allok &= run(nbk)
        print()
    print("ALL PASS" if allok else "SOME FAILED")
