      PROGRAM STEGR_RES
*     stegr_ID DSTEGR on M = T-mu*I (= B^T B): report orthU AND the
*     residual max_j ||M z_j - w_j z_j|| / ||M||  (M tridiagonal).
      IMPLICIT NONE
      INTEGER NMAX, LWK, LIWK
      PARAMETER ( NMAX=400, LWK=40*NMAX, LIWK=20*NMAX )
      DOUBLE PRECISION A(NMAX),BO(NMAX),DM(NMAX),EM(NMAX),D(NMAX),
     $   E(NMAX),W(NMAX),Z(NMAX,NMAX),WK(LWK),GC,ORTH,MU,GMIN,
     $   RES,RJ,T1,ANRM
      INTEGER IWK(LIWK),ISUP(2*NMAX),N,I,J,K,M,INFO,IDX
      DOUBLE PRECISION AA,BB
      CHARACTER*120 FN
      CALL GET_COMMAND_ARGUMENT(1,FN)
      OPEN(10,FILE=FN,STATUS='OLD')
      READ(10,*) N
      DO 10 I=1,N
         READ(10,*) IDX,AA,BB
         A(I)=AA
         IF(I.LT.N) BO(I)=BB
   10 CONTINUE
      CLOSE(10)
      BO(N)=0.0D0
      GMIN=A(1)-ABS(BO(1))
      DO 20 I=2,N
         GMIN=MIN(GMIN,A(I)-ABS(BO(I-1))-ABS(BO(I)))
   20 CONTINUE
      MU = GMIN - 1.0D-3*ABS(GMIN) - 1.0D-30
      DO 30 I=1,N
         DM(I)=A(I)-MU
         EM(I)=BO(I)
         D(I)=DM(I)
         E(I)=EM(I)
   30 CONTINUE
      ANRM=0.0D0
      DO 31 I=1,N
         ANRM=MAX(ANRM,ABS(DM(I))+ABS(EM(I))+ABS(EM(MAX(I-1,1))))
   31 CONTINUE
      CALL DSTEGR('V','A',N,D,E,0.0D0,0.0D0,1,N,0.0D0,M,W,Z,NMAX,
     $            ISUP,WK,LWK,IWK,LIWK,INFO)
      ORTH=0.0D0
      DO 50 J=1,M
      DO 40 I=1,M
         GC=0.0D0
         DO 35 K=1,N
            GC=GC+Z(K,I)*Z(K,J)
   35    CONTINUE
         IF(I.EQ.J) GC=GC-1.0D0
         ORTH=MAX(ORTH,ABS(GC))
   40 CONTINUE
   50 CONTINUE
*     residual: M z_j - w_j z_j  (M tridiag DM,EM)
      RES=0.0D0
      DO 70 J=1,M
         RJ=0.0D0
         DO 60 I=1,N
            T1=DM(I)*Z(I,J)
            IF(I.GT.1) T1=T1+EM(I-1)*Z(I-1,J)
            IF(I.LT.N) T1=T1+EM(I)*Z(I+1,J)
            T1=T1-W(J)*Z(I,J)
            RJ=RJ+T1*T1
   60    CONTINUE
         RES=MAX(RES,SQRT(RJ))
   70 CONTINUE
      WRITE(*,*) 'INFO=',INFO,' orthU=',ORTH,' resid/||M||=',RES/ANRM
      STOP
      END
