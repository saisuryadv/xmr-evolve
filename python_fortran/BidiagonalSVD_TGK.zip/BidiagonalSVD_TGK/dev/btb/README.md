# B^T B definite-root SVD experiment

Comparison of root representations for the bidiagonal SVD via MR^3:
the current TGK (Golub-Kahan) root vs a definite L D L^T root from B^T B
(the Grosser-Lang / one-sided approach), run through the OLDER stegr_ID
MR^3 (DSTEGR), which -- unlike modern LAPACK DSTEMR -- does NOT reject
the element-growth RRR and so completes on these matrices.

Files (all standalone; link stegr_ID/*.o before -llapack so the older
MR^3 routines override LAPACK's):
- svd_btb.f          : full SVD of L=chol(T-mu I) via DSTEGR on L L^T
                       (-> U, sigma) and V = L^T U / sigma. Reports
                       orthU, orthV, rel.resid. (V is DERIVED -> loses
                       accuracy for small sigma; a two-sided/coupled
                       version would fix that.)
- stegr_res.f        : DSTEGR on T-mu I, reports orthU and residual.
- stegr_old_test.f   : DSTEGR on B^T B and on T (lambda-space), orthU.
- stemr_test_modern.f: same via MODERN LAPACK DSTEMR -- FAILS (INFO=22)
                       on the strong-glue matrices (element-growth
                       rejection + DSTEIN fallback dies); kept to show
                       why the stegr_ID version is needed.

Build (example):
  gfortran -c -O2 -std=legacy -fno-automatic stegr_ID/dlar1v.f \
     stegr_ID/dlarrb.f stegr_ID/dlarre.f stegr_ID/dlarrf.f \
     stegr_ID/dlarrv.f stegr_ID/dlasrt2.f stegr_ID/dstegr.f \
     stegr_ID/ilasrt2.f
  gfortran -O2 -std=legacy -fno-automatic dev/btb/svd_btb.f *.o \
     -L$HOME/miniforge3/lib -llapack -lblas -o build/svd_btb

Head-to-head (orthU), dim-2100 glued Wilkinson:
  glue   TGK        B^T B
  1e+00  8.9e-13    5.1e-10   (TGK better: localized bit-identical)
  1e+02  2.6e-8     5.9e-10   (B^T B better)
  1e+04  2.9e-10    6.6e-9    (TGK better)
  1e+06  8.2e-11    1.3e-8    (TGK better)
  1e+12  6.4e-6     2.1e-11   (B^T B MUCH better: interior-compressed)
  1e+14  2.0e-9     2.6e-13   (B^T B better)
Conclusion: complementary. Definite B^T B root resolves interior-
compressed clusters that the indefinite TGK degrades on; TGK wins on
localized bit-identical clusters. A two-sided (coupled) B^T B would also
fix the derived-V small-sigma loss.
