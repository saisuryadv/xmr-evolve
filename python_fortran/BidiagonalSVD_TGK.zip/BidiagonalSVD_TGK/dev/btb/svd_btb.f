      PROGRAM SVD_BTB
*     Bidiagonal SVD via a DEFINITE B^T B root + stegr_ID MR^3 (DSTEGR),
*     for head-to-head comparison with the TGK-rooted DBDSVDMR3.
*     Reads a symmetric tridiagonal T (same input as test_chol_big), forms
*     the lower bidiagonal L = chol(T - mu I) (mu=0 first, else Gershgorin),
*     then computes the SVD of L by running DSTEGR on  L L^T = T - mu I
*     (eigenvalues sigma^2, eigenvectors U), and V = L^T U / sigma.
*     Reports orthU, orthV and rel.resid ||L - U S V^T||/sigma_max.
      IMPLICIT NONE
      INTEGER NMAX, LWK, LIWK
      PARAMETER ( NMAX=2600, LWK=40*NMAX, LIWK=20*NMAX )
      DOUBLE PRECISION A(NMAX),BO(NMAX),DD(NMAX),EE(NMAX),D(NMAX),
     $   E(NMAX),W(NMAX),SG(NMAX),U(NMAX,NMAX),V(NMAX,NMAX),
     $   GC(NMAX,NMAX),WK(LWK)
      DOUBLE PRECISION MU,GMIN,PIV,ORTHU,ORTHV,RESID,SMAX,TMP,LIJ,
     $   AA,BB,ONE,ZERO
      INTEGER IWK(LIWK),ISUP(2*NMAX),N,I,J,K,M,INFO,IDX
      CHARACTER*120 FN
      PARAMETER ( ONE=1.0D0, ZERO=0.0D0 )
      EXTERNAL DSTEGR, DGEMM
      CALL GET_COMMAND_ARGUMENT(1,FN)
      OPEN(10,FILE=FN,STATUS='OLD')
      READ(10,*) N
      DO 10 I=1,N
         READ(10,*) IDX,AA,BB
         A(I)=AA
         IF(I.LT.N) BO(I)=BB
   10 CONTINUE
      CLOSE(10)
      BO(N)=ZERO
*     Gershgorin lower bound; mu=0 first, else shift just below it.
      GMIN=A(1)-ABS(BO(1))
      DO 20 I=2,N
         GMIN=MIN(GMIN,A(I)-ABS(BO(I-1))-ABS(BO(I)))
   20 CONTINUE
      MU=ZERO
   25 CONTINUE
      PIV=A(1)-MU
      IF(PIV.LE.ZERO) GO TO 28
      DD(1)=SQRT(PIV)
      DO 30 I=1,N-1
         EE(I)=BO(I)/DD(I)
         PIV=(A(I+1)-MU)-EE(I)*EE(I)
         IF(PIV.LE.ZERO) GO TO 28
         DD(I+1)=SQRT(PIV)
   30 CONTINUE
      GO TO 35
   28 CONTINUE
      IF(MU.EQ.ZERO .AND. GMIN.LE.ZERO) THEN
         MU=GMIN-1.0D-3*ABS(GMIN)-1.0D-30
         GO TO 25
      END IF
      WRITE(*,*) 'Cholesky failed'
      STOP
   35 CONTINUE
      EE(N)=ZERO
*     DSTEGR on T - mu I = L L^T  (eigenvalues sigma^2, eigenvectors U).
      DO 36 I=1,N
         D(I)=A(I)-MU
         E(I)=BO(I)
   36 CONTINUE
      CALL DSTEGR('V','A',N,D,E,ZERO,ZERO,1,N,ZERO,M,W,U,NMAX,
     $            ISUP,WK,LWK,IWK,LIWK,INFO)
      SMAX=ZERO
      DO 37 I=1,M
         SG(I)=SQRT(MAX(W(I),ZERO))
         SMAX=MAX(SMAX,SG(I))
   37 CONTINUE
*     V = L^T U / sigma :  (L^T U)(i,j) = DD(i)U(i,j) + EE(i)U(i+1,j).
      DO 45 J=1,M
         DO 40 I=1,N
            TMP=DD(I)*U(I,J)
            IF(I.LT.N) TMP=TMP+EE(I)*U(I+1,J)
            IF(SG(J).GT.ZERO) THEN
               V(I,J)=TMP/SG(J)
            ELSE
               V(I,J)=ZERO
            END IF
   40    CONTINUE
   45 CONTINUE
*     orthU = max|U^T U - I|
      CALL DGEMM('T','N',M,M,N,ONE,U,NMAX,U,NMAX,ZERO,GC,NMAX)
      ORTHU=ZERO
      DO 55 J=1,M
      DO 50 I=1,M
         TMP=GC(I,J)
         IF(I.EQ.J) TMP=TMP-ONE
         ORTHU=MAX(ORTHU,ABS(TMP))
   50 CONTINUE
   55 CONTINUE
*     orthV = max|V^T V - I|
      CALL DGEMM('T','N',M,M,N,ONE,V,NMAX,V,NMAX,ZERO,GC,NMAX)
      ORTHV=ZERO
      DO 65 J=1,M
      DO 60 I=1,M
         TMP=GC(I,J)
         IF(I.EQ.J) TMP=TMP-ONE
         ORTHV=MAX(ORTHV,ABS(TMP))
   60 CONTINUE
   65 CONTINUE
*     resid: V := sigma * V (scale columns), then GC = U * V^T, vs L.
      DO 75 J=1,M
      DO 70 I=1,N
         V(I,J)=SG(J)*V(I,J)
   70 CONTINUE
   75 CONTINUE
      CALL DGEMM('N','T',N,N,M,ONE,U,NMAX,V,NMAX,ZERO,GC,NMAX)
      RESID=ZERO
      DO 85 J=1,N
      DO 80 I=1,N
         LIJ=ZERO
         IF(I.EQ.J) LIJ=DD(I)
         IF(I.EQ.J+1) LIJ=EE(J)
         RESID=MAX(RESID,ABS(GC(I,J)-LIJ))
   80 CONTINUE
   85 CONTINUE
      IF(SMAX.GT.ZERO) RESID=RESID/SMAX
      WRITE(*,90) N,INFO,SG(1),SMAX,RESID,ORTHU,ORTHV
   90 FORMAT(' N=',I5,' INFO=',I3,' smin=',E11.4,' smax=',E11.4,/,
     $   '   rel.resid=',E11.4,'  orthU=',E11.4,'  orthV=',E11.4)
      STOP
      END
