      PROGRAM STEMR_TEST
*     Run LAPACK MRRR (DSTEMR) on (a) T-mu*I = L L^T  (= B^T B, eigenvalues
*     sigma^2, the user's proposed root) and (b) the original T (lambda-
*     space), and report eigenvector orthogonality max|Z^T Z - I|.
      IMPLICIT NONE
      INTEGER NMAX, LWK, LIWK
      PARAMETER ( NMAX=400, LWK=40*NMAX, LIWK=20*NMAX )
      DOUBLE PRECISION A(NMAX),BO(NMAX),D(NMAX),E(NMAX),W(NMAX)
      DOUBLE PRECISION Z(NMAX,NMAX),WK(LWK),GC,TMP,ORTH,MU,GMIN
      INTEGER IWK(LIWK),ISUP(2*NMAX),N,I,J,K,M,INFO,IDX
      DOUBLE PRECISION AA,BB
      LOGICAL TRYRAC
      CHARACTER*120 FN
      CALL GET_COMMAND_ARGUMENT(1,FN)
      OPEN(10,FILE=FN,STATUS='OLD')
      READ(10,*) N
      DO 10 I=1,N
         READ(10,*) IDX,AA,BB
         A(I)=AA
         IF(I.LT.N) BO(I)=BB
   10 CONTINUE
      CLOSE(10)
      BO(N)=0.0D0
      GMIN=A(1)-ABS(BO(1))
      DO 20 I=2,N
         GMIN=MIN(GMIN,A(I)-ABS(BO(I-1))-ABS(BO(I)))
   20 CONTINUE
      MU = GMIN - 1.0D-3*ABS(GMIN) - 1.0D-30
*     --- case (a): T - mu I  (eigenvalues sigma^2) ---
      DO 30 I=1,N
         D(I)=A(I)-MU
         E(I)=BO(I)
   30 CONTINUE
      TRYRAC=.TRUE.
      CALL DSTEMR('V','A',N,D,E,0.0D0,0.0D0,1,N,M,W,Z,NMAX,N,ISUP,
     $            TRYRAC,WK,LWK,IWK,LIWK,INFO)
      ORTH=0.0D0
      DO 50 J=1,M
      DO 40 I=1,M
         GC=0.0D0
         DO 35 K=1,N
            GC=GC+Z(K,I)*Z(K,J)
   35    CONTINUE
         IF(I.EQ.J) GC=GC-1.0D0
         ORTH=MAX(ORTH,ABS(GC))
   40 CONTINUE
   50 CONTINUE
      WRITE(*,*) 'B^T B (T-mu I): INFO=',INFO,' M=',M,' orthU=',ORTH
*     --- case (b): original T (lambda-space) ---
      DO 60 I=1,N
         D(I)=A(I)
         E(I)=BO(I)
   60 CONTINUE
      TRYRAC=.TRUE.
      CALL DSTEMR('V','A',N,D,E,0.0D0,0.0D0,1,N,M,W,Z,NMAX,N,ISUP,
     $            TRYRAC,WK,LWK,IWK,LIWK,INFO)
      ORTH=0.0D0
      DO 90 J=1,M
      DO 80 I=1,M
         GC=0.0D0
         DO 70 K=1,N
            GC=GC+Z(K,I)*Z(K,J)
   70    CONTINUE
         IF(I.EQ.J) GC=GC-1.0D0
         ORTH=MAX(ORTH,ABS(GC))
   80 CONTINUE
   90 CONTINUE
      WRITE(*,*) 'orig  T (lambda): INFO=',INFO,' M=',M,' orth =',ORTH
      STOP
      END
