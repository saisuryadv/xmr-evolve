      PROGRAM STEGR_OLD
*     Run the OLDER stegr_ID MR^3 (DSTEGR) on T-mu*I (= B^T B, eigenvalues
*     sigma^2 -- the user's proposed root) and on T, report orthogonality.
      IMPLICIT NONE
      INTEGER NMAX, LWK, LIWK
      PARAMETER ( NMAX=400, LWK=40*NMAX, LIWK=20*NMAX )
      DOUBLE PRECISION A(NMAX),BO(NMAX),D(NMAX),E(NMAX),W(NMAX)
      DOUBLE PRECISION Z(NMAX,NMAX),WK(LWK),GC,ORTH,MU,GMIN,ABSTOL
      INTEGER IWK(LIWK),ISUP(2*NMAX),N,I,J,K,M,INFO,IDX
      DOUBLE PRECISION AA,BB
      CHARACTER*120 FN
      CALL GET_COMMAND_ARGUMENT(1,FN)
      OPEN(10,FILE=FN,STATUS='OLD')
      READ(10,*) N
      DO 10 I=1,N
         READ(10,*) IDX,AA,BB
         A(I)=AA
         IF(I.LT.N) BO(I)=BB
   10 CONTINUE
      CLOSE(10)
      BO(N)=0.0D0
      GMIN=A(1)-ABS(BO(1))
      DO 20 I=2,N
         GMIN=MIN(GMIN,A(I)-ABS(BO(I-1))-ABS(BO(I)))
   20 CONTINUE
      MU = GMIN - 1.0D-3*ABS(GMIN) - 1.0D-30
      ABSTOL = 0.0D0
*     (a) B^T B = T - mu I  (eigenvalues sigma^2)
      DO 30 I=1,N
         D(I)=A(I)-MU
         E(I)=BO(I)
   30 CONTINUE
      CALL DSTEGR('V','A',N,D,E,0.0D0,0.0D0,1,N,ABSTOL,M,W,Z,NMAX,
     $            ISUP,WK,LWK,IWK,LIWK,INFO)
      ORTH=0.0D0
      DO 50 J=1,M
      DO 40 I=1,M
         GC=0.0D0
         DO 35 K=1,N
            GC=GC+Z(K,I)*Z(K,J)
   35    CONTINUE
         IF(I.EQ.J) GC=GC-1.0D0
         ORTH=MAX(ORTH,ABS(GC))
   40 CONTINUE
   50 CONTINUE
      WRITE(*,*) 'B^T B (T-mu I): INFO=',INFO,' M=',M,' orthU=',ORTH
*     (b) original T (lambda)
      DO 60 I=1,N
         D(I)=A(I)
         E(I)=BO(I)
   60 CONTINUE
      CALL DSTEGR('V','A',N,D,E,0.0D0,0.0D0,1,N,ABSTOL,M,W,Z,NMAX,
     $            ISUP,WK,LWK,IWK,LIWK,INFO)
      ORTH=0.0D0
      DO 90 J=1,M
      DO 80 I=1,M
         GC=0.0D0
         DO 70 K=1,N
            GC=GC+Z(K,I)*Z(K,J)
   70    CONTINUE
         IF(I.EQ.J) GC=GC-1.0D0
         ORTH=MAX(ORTH,ABS(GC))
   80 CONTINUE
   90 CONTINUE
      WRITE(*,*) 'orig  T (lambda): INFO=',INFO,' M=',M,' orth =',ORTH
      STOP
      END
