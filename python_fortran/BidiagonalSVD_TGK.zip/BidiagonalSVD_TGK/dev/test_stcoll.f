      PROGRAM TEST_STCOLL
*
*     Read an (upper) bidiagonal matrix from an STCollection .dat file
*     (dim on row 1, then (index, diagonal, off-diagonal) rows), compute
*     its SVD with DBDSVDMR3, and compare against dense LAPACK DGESVD.
*     Filename is passed as the first command-line argument.
*
      IMPLICIT NONE
      INTEGER NMAX, LWORK, LIWORK, LDU, LDVT
      PARAMETER ( NMAX = 500, LDU = NMAX, LDVT = NMAX )
      PARAMETER ( LWORK = 4*NMAX*NMAX+100*NMAX, LIWORK = 30*NMAX )
      INTEGER N, M, INFO, I, J, K, IDX, IOS, IWORK(LIWORK)
      DOUBLE PRECISION D(NMAX), E(NMAX), S(NMAX)
      DOUBLE PRECISION U(LDU,NMAX), VT(LDVT,NMAX), WORK(LWORK)
      DOUBLE PRECISION SREF(NMAX)
      DOUBLE PRECISION RESID, ORTHU, ORTHV, TMP, SDIFF, SMAX, SMIN
      DOUBLE PRECISION DD, EE, RELSV, NEPS
      CHARACTER*256 FNAME
      DOUBLE PRECISION DLAMCH
      EXTERNAL DBDSVDMR3, DGESVD, DLAMCH
      INTRINSIC ABS, MAX, MIN, DBLE
*
      CALL GET_COMMAND_ARGUMENT( 1, FNAME )
      OPEN( UNIT=10, FILE=FNAME, STATUS='OLD', IOSTAT=IOS )
      IF( IOS.NE.0 ) THEN
         WRITE(*,*) 'cannot open ', FNAME
         STOP
      END IF
      READ(10,*) N
      DO I=1,N
         READ(10,*) IDX, DD, EE
         D(I)=DD
         E(I)=EE
      END DO
      CLOSE(10)
      E(N)=0.0D0
*
*     Dense UPPER bidiagonal B for DGESVD: B(i,i)=D(i), B(i,i+1)=E(i).
*     (DGESVD destroys its input; use WORK region as scratch B copy via
*     an explicit array U as scratch is unsafe, so build into VT-sized
*     temp; instead store B in U then copy.)  Use a local approach: put
*     dense B in the leading N-by-N of array passed to DGESVD = use S? no.
*     We allocate B on the fly in WORK is messy; reuse UR=U as B scratch.
*
      DO J=1,N
         DO I=1,N
            U(I,J)=0.0D0
         END DO
      END DO
      DO I=1,N
         U(I,I)=D(I)
      END DO
      DO I=1,N-1
         U(I,I+1)=E(I)
      END DO
      CALL DGESVD('N','N',N,N,U,LDU,SREF,VT,LDVT,VT,LDVT,WORK,LWORK,
     $            INFO)
      IF( INFO.NE.0 ) WRITE(*,*) '  (DGESVD INFO=',INFO,')'
*
      CALL DBDSVDMR3('V','U',N,D,E,S,U,LDU,VT,LDVT,M,WORK,LWORK,
     $               IWORK,LIWORK,INFO)
*
*     NaN/Inf audit (the orthogonality MAX-reduction silently drops NaN).
      K = 0
      DO 71 J = 1, M
         IF( .NOT.( S(J).EQ.S(J) .AND. ABS(S(J)).LE.1.0D300 ) ) K = K+1
         DO 70 I = 1, N
            IF( .NOT.( U(I,J).EQ.U(I,J) .AND.
     $                ABS(U(I,J)).LE.1.0D300 ) ) K = K + 1
            IF( .NOT.( VT(J,I).EQ.VT(J,I) .AND.
     $                ABS(VT(J,I)).LE.1.0D300 ) ) K = K + 1
   70    CONTINUE
   71 CONTINUE
      IF( K.GT.0 ) WRITE(*,*) '   *** NON-FINITE OUTPUT: ',K,
     $   ' bad entries in S/U/V ***'
*
*     Rebuild dense B to check the residual (U/VT now hold the SVD).
*
      SMAX=0.0D0
      SMIN=1.0D30
      DO I=1,M
         SMAX=MAX(SMAX,S(I))
         IF(S(I).GT.0.0D0) SMIN=MIN(SMIN,S(I))
      END DO
*
      SDIFF=0.0D0
      RELSV=0.0D0
      DO I=1,M
         SDIFF=MAX(SDIFF,ABS(S(I)-SREF(M-I+1)))
         IF(SREF(M-I+1).GT.0.0D0)
     $      RELSV=MAX(RELSV,ABS(S(I)-SREF(M-I+1))/SREF(M-I+1))
      END DO
*
*     residual ||B - U S V^T|| (rebuild B entries on the fly).
*
      RESID=0.0D0
      DO I=1,N
         DO J=1,N
            TMP=0.0D0
            DO K=1,M
               TMP=TMP+U(I,K)*S(K)*VT(K,J)
            END DO
            DD=0.0D0
            IF(I.EQ.J) DD=D(I)
            IF(J.EQ.I+1) DD=E(I)
            RESID=MAX(RESID,ABS(TMP-DD))
         END DO
      END DO
*
      ORTHU=0.0D0
      ORTHV=0.0D0
      DO I=1,M
         DO J=1,M
            TMP=0.0D0
            DO K=1,N
               TMP=TMP+U(K,I)*U(K,J)
            END DO
            IF(I.EQ.J) TMP=TMP-1.0D0
            ORTHU=MAX(ORTHU,ABS(TMP))
            TMP=0.0D0
            DO K=1,N
               TMP=TMP+VT(I,K)*VT(J,K)
            END DO
            IF(I.EQ.J) TMP=TMP-1.0D0
            ORTHV=MAX(ORTHV,ABS(TMP))
         END DO
      END DO
*
      IF( SMAX.GT.0.0D0 ) RESID = RESID / SMAX
      WRITE(*,900) N, M, INFO, SMIN, SMAX, SDIFF, RELSV, RESID,
     $             ORTHU, ORTHV
  900 FORMAT(' N=',I4,' M=',I4,' INFO=',I3,' smin=',E10.3,
     $       ' smax=',E10.3,/,'   absdiff=',E10.3,' reldiff=',E10.3,
     $       ' rel.resid=',E10.3,' orthU=',E10.3,' orthV=',E10.3)
*     As multiples of n*eps (n = N, eps = DLAMCH('Precision') ~ 2.22e-16):
*       resid = ||B-USV^T|| / (n*eps*||B||);  orth = ||Q^T Q - I|| / (n*eps).
      NEPS = DBLE( N )*DLAMCH( 'Precision' )
      WRITE(*,910) RESID/NEPS, ORTHU/NEPS, ORTHV/NEPS
  910 FORMAT('   resid/(n.eps.||B||)=',F11.1,
     $       '   orthU/(n.eps)=',F11.1,'   orthV/(n.eps)=',F11.1)
      STOP
      END
