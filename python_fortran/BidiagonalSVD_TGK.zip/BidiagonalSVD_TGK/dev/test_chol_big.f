      PROGRAM TEST_CHOL_BIG
*
*     Large-matrix version of test_chol.f for the indefinite Godunov
*     matrices (dim ~2500).  Reads a symmetric tridiagonal T, forms a
*     lower-bidiagonal Cholesky factor L of T - mu*I (mu chosen via a
*     Gershgorin bound so T - mu*I is positive definite), runs DBDSVDMR3
*     on L, and checks:
*       - eigenvalue recovery sigma_i^2 + mu vs DSTEV(T)  (relative);
*       - relative residual ||L - U S V^T|| / sigma_max;
*       - orthogonality of U and V.
*     Residual and orthogonality use BLAS (DGEMM) so the checks are fast
*     at this size.  Compile with -fno-automatic (large static arrays).
*     Tridiagonal file is the first command-line argument.
*
      IMPLICIT NONE
      INTEGER NMAX, LWORK, LIWORK, LDU, LDVT
      PARAMETER ( NMAX = 2600, LDU = NMAX, LDVT = NMAX )
      PARAMETER ( LWORK = 2*NMAX*NMAX + 40*NMAX, LIWORK = 25*NMAX )
      DOUBLE PRECISION ZERO, ONE
      PARAMETER ( ZERO = 0.0D0, ONE = 1.0D0 )
      INTEGER N, M, INFO, I, J, K, IDX, IOS, KB, IWORK(LIWORK)
      DOUBLE PRECISION A(NMAX), BO(NMAX), D(NMAX), E(NMAX), S(NMAX)
      DOUBLE PRECISION D0(NMAX), E0(NMAX), WE(NMAX)
      DOUBLE PRECISION U(LDU,NMAX), VT(LDVT,NMAX), GC(NMAX,NMAX)
      DOUBLE PRECISION WORK(LWORK)
      DOUBLE PRECISION AA, BB, MU, GMIN, PIV, RESID, ORTHU, ORTHV
      DOUBLE PRECISION EVREL, TMP, LIJ, SMIN, SMAX, TNRM, NEPS
      CHARACTER*256 FNAME
      DOUBLE PRECISION DLAMCH
      EXTERNAL DBDSVDMR3, DSTEV, DGEMM, DSCAL, DLAMCH
      INTRINSIC ABS, MAX, MIN, SQRT, DBLE
*
      CALL GET_COMMAND_ARGUMENT( 1, FNAME )
      OPEN( UNIT=10, FILE=FNAME, STATUS='OLD', IOSTAT=IOS )
      IF( IOS.NE.0 ) THEN
         WRITE(*,*) 'cannot open ', FNAME
         STOP
      END IF
      READ(10,*) N
      DO 10 I = 1, N
         READ(10,*) IDX, AA, BB
         A( I ) = AA
         BO( I ) = BB
   10 CONTINUE
      CLOSE(10)
      BO( N ) = ZERO
*
      GMIN = A( 1 ) - ABS( BO( 1 ) )
      DO 20 I = 2, N
         GMIN = MIN( GMIN, A( I ) - ABS( BO( I-1 ) ) - ABS( BO( I ) ) )
   20 CONTINUE
*     Try mu = 0 first (the Gershgorin bound is often pessimistically
*     negative for a PD matrix); only shift if Cholesky actually breaks.
      MU = ZERO
   25 CONTINUE
      PIV = A( 1 ) - MU
      IF( PIV.LE.ZERO ) GO TO 28
      D( 1 ) = SQRT( PIV )
      DO 30 I = 1, N - 1
         E( I ) = BO( I ) / D( I )
         PIV = ( A( I+1 ) - MU ) - E( I )*E( I )
         IF( PIV.LE.ZERO ) GO TO 28
         D( I+1 ) = SQRT( PIV )
   30 CONTINUE
      GO TO 35
   28 CONTINUE
      IF( MU.EQ.ZERO .AND. GMIN.LE.ZERO ) THEN
         MU = GMIN - 1.0D-3*ABS( GMIN ) - 1.0D-30
         GO TO 25
      END IF
      WRITE(*,*) 'Cholesky non-positive pivot even after shift'
      STOP
   35 CONTINUE
      E( N ) = ZERO
      DO 40 I = 1, N
         D0( I ) = D( I )
         E0( I ) = E( I )
   40 CONTINUE
*
*     Reference eigenvalues of T (DSTEV, ascending).
*
      DO 50 I = 1, N
         WE( I ) = A( I )
   50 CONTINUE
      DO 55 I = 1, N - 1
         WORK( I ) = BO( I )
   55 CONTINUE
      CALL DSTEV( 'N', N, WE, WORK, U, LDU, WORK(N+1), INFO )
*
      CALL DBDSVDMR3( 'V', 'L', N, D, E, S, U, LDU, VT, LDVT, M, WORK,
     $                LWORK, IWORK, LIWORK, INFO )
      WRITE(*,200) N, INFO, M, MU
  200 FORMAT( ' N=', I5, ' INFO=', I3, ' M=', I5, ' shift mu=', E13.6 )
*     Explicit NaN/Inf audit of the outputs.  The orthogonality MAX-
*     reduction below silently drops NaN (gfortran MAX(finite,NaN)=finite),
*     so count non-finite entries directly: a single NaN singular vector
*     would otherwise masquerade as orthonormal.  IDX = bad S; J = bad U;
*     K = bad VT entries.
      IDX = 0
      DO 61 I = 1, M
         IF( .NOT.( S(I).EQ.S(I) .AND. ABS(S(I)).LE.1.0D300 ) )
     $      IDX = IDX + 1
   61 CONTINUE
      J = 0
      K = 0
      DO 63 KB = 1, M
         DO 62 I = 1, N
            IF( .NOT.( U(I,KB).EQ.U(I,KB) .AND.
     $                ABS(U(I,KB)).LE.1.0D300 ) ) J = J + 1
            IF( .NOT.( VT(KB,I).EQ.VT(KB,I) .AND.
     $                ABS(VT(KB,I)).LE.1.0D300 ) ) K = K + 1
   62    CONTINUE
   63 CONTINUE
      IF( IDX+J+K.GT.0 ) WRITE(*,205) IDX, J, K
  205 FORMAT( '   *** NON-FINITE OUTPUT ***  badS=', I6,
     $        '  badU=', I8, '  badV=', I8 )
*
      SMIN = 1.0D30
      SMAX = ZERO
      DO 60 I = 1, M
         SMAX = MAX( SMAX, S( I ) )
         IF( S( I ).GT.ZERO ) SMIN = MIN( SMIN, S( I ) )
   60 CONTINUE
*
*     Eigenvalue recovery: sigma_i^2 + mu vs eig(T), relative to ||T||.
*
      TNRM = MAX( ABS( WE( 1 ) ), ABS( WE( N ) ) )
      EVREL = ZERO
      DO 70 I = 1, M
         EVREL = MAX( EVREL, ABS( S( I )*S( I )+MU - WE( I ) ) )
   70 CONTINUE
      IF( TNRM.GT.ZERO ) EVREL = EVREL / TNRM
*
*     Orthogonality via BLAS (before VT is scaled below).
*     GC = U^T U  (M x M);  orthU = max|GC - I|.
*
      CALL DGEMM( 'T', 'N', M, M, N, ONE, U, LDU, U, LDU, ZERO, GC,
     $            NMAX )
      ORTHU = ZERO
      DO 90 J = 1, M
         DO 80 I = 1, M
            TMP = GC( I, J )
            IF( I.EQ.J ) TMP = TMP - ONE
            ORTHU = MAX( ORTHU, ABS( TMP ) )
   80    CONTINUE
   90 CONTINUE
*     GC = VT VT^T  (M x M);  orthV = max|GC - I|.
      CALL DGEMM( 'N', 'T', M, M, N, ONE, VT, LDVT, VT, LDVT, ZERO, GC,
     $            NMAX )
      ORTHV = ZERO
      DO 110 J = 1, M
         DO 100 I = 1, M
            TMP = GC( I, J )
            IF( I.EQ.J ) TMP = TMP - ONE
            ORTHV = MAX( ORTHV, ABS( TMP ) )
  100    CONTINUE
  110 CONTINUE
*
*     Relative residual ||L - U S V^T|| / sigma_max via BLAS.  Scale the
*     rows of VT by S (VT := S * VT), then GC = U * (S V^T).
*
      DO 120 K = 1, M
         CALL DSCAL( N, S( K ), VT( K, 1 ), LDVT )
  120 CONTINUE
      CALL DGEMM( 'N', 'N', N, N, M, ONE, U, LDU, VT, LDVT, ZERO, GC,
     $            NMAX )
      RESID = ZERO
      DO 140 J = 1, N
         DO 130 I = 1, N
            LIJ = ZERO
            IF( I.EQ.J ) LIJ = D0( I )
            IF( I.EQ.J+1 ) LIJ = E0( J )
            RESID = MAX( RESID, ABS( GC( I, J )-LIJ ) )
  130    CONTINUE
  140 CONTINUE
      IF( SMAX.GT.ZERO ) RESID = RESID / SMAX
*
      WRITE(*,210) SMIN, SMAX
  210 FORMAT( '   sigma_min=', E13.6, '  sigma_max=', E13.6 )
      WRITE(*,220) EVREL, RESID, ORTHU, ORTHV
  220 FORMAT( '   rel eig-recovery=', E11.4, '  rel resid=', E11.4,
     $        '  orthU=', E11.4, '  orthV=', E11.4 )
*     Same residual / orthogonality, expressed as multiples of n*eps:
*       resid as ||L-USV^T|| / (n*eps*||L||)      [RESID is already /sigma_max]
*       orth  as ||U^T U - I||_max / (n*eps), likewise for V.
*     n = N (bidiagonal order), eps = DLAMCH('Precision') ~ 2.22e-16.
      NEPS = DBLE( N )*DLAMCH( 'Precision' )
      WRITE(*,230) RESID/NEPS, ORTHU/NEPS, ORTHV/NEPS
  230 FORMAT( '   resid/(n.eps.||L||)=', F11.1,
     $        '   orthU/(n.eps)=', F11.1, '   orthV/(n.eps)=', F11.1 )
      STOP
      END
