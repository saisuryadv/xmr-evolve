# Bidiagonal SVD via TGK-rooted MR³ — design

New Fortran code that computes the SVD of a bidiagonal matrix `B` (diagonal `d`,
off-diagonal `e`) by running tridiagonal MR³ with the **Tridiagonal Golub–Kahan (TGK)
matrix as the root** of the representation tree.

`stegr_ID/` is the LAPACK MR³ reference and is **read-only**. All new code lives here in
the project root; below the first level of the tree it calls the *unmodified* `stegr_ID`
routines.

## The TGK matrix

For `B` of order `n` (lower or upper bidiagonal), the Golub–Kahan tridiagonal `T_GK` is the
symmetric tridiagonal of order `2n` with **zero diagonal** and off-diagonals interleaving
`d` and `e`:

```
diag(T_GK)   = 0                       (length 2n)
offdiag(T_GK)= [ d_1, e_1, d_2, e_2, ..., e_{n-1}, d_n ]   (length 2n-1)
```

Eigenvalues of `T_GK` are `±σ_i`; eigenvectors interleave the left/right singular vectors:
the eigenvector for `+σ_i` is `(1/√2)[ u_i(1), v_i(1), u_i(2), v_i(2), ... ]` (up to sign).
We keep only the **positive** eigenvalues — they are exactly the singular values.

Two facts from the 1997 thesis justify rooting the tree here:
- **Kahan (1966), §4.3**: a zero-diagonal symmetric tridiagonal determines its eigenvalues
  to high *relative* accuracy under relative perturbations of the off-diagonals ⇒ `T_GK` is
  a relatively robust root.
- **Cor. 3.3.1**: a zero-diagonal tridiagonal has a `±` symmetric spectrum.

## Pipeline (mirrors DSTEGR → DLARRE → DLARRV)

1. **Split** `B` where `|e_i| ≤ tol·‖B‖` (tol absolute, scaled by the norm). Each block is
   handled independently.
2. **Singular values** per block via **DLASQ1** (dqds) — standard LAPACK, linked, not copied.
3. **Form `T_GK`** for the block (the `(0, β)` arrays above).
4. **MR³ rooted at `T_GK`**:
   - (a) root representation = `T_GK` itself (not `LDLᵀ`);
   - (b) positive eigenvalue with **large** relative gap → eigenvector directly via
     `dlar1v_tgk` (TGK-input path);
   - (c) **cluster** (relgap ≲ 1e-3) → child RRR `LDLᵀ` formed *from `T_GK`* via
     `dlarrf_tgk` (TGK-input path);
   - (d) every node below level 1 is `LDLᵀ` ⇒ unmodified `stegr_ID` (`dlar1v`, `dlarrf`, …).

"No 2×2 pivots": the root is zero-diagonal and indefinite (`±σ`), so the qd transforms run
on `(diag=0, β)` data and **zero pivots are expected** (e.g. odd leading submatrices are
singular at `σ=0`, thesis Lemma 3.3.1). They are handled with IEEE ∞/NaN arithmetic exactly
as in `dlar1v.f` §3.3 — never with 2×2 pivoting.

## New files

| File | Role | Based on |
|---|---|---|
| `dlar1v_tgk.f` | r-th column of `(M − σI)⁻¹` (eigenvector), `M` = `T_GK` **or** `LDLᵀ` | `stegr_ID/dlar1v.f` |
| `dlarrf_tgk.f` | child RRR `LDLᵀ = M − σI`, `M` = `T_GK` **or** `LDLᵀ` | `stegr_ID/dlarrf.f` |
| `dbdtgk.f` *(planned)* | build `(0,β)` TGK arrays from `(d,e)` | — |
| `dlarrv_tgk.f` *(planned)* | tree driver; level-1 nodes use `*_tgk`, deeper nodes use `stegr_ID` | `stegr_ID/dlarrv.f` |
| `dbdsvdmr3.f` *(planned)* | top-level SVD driver: split → dqds → TGK → tree | `stegr_ID/dstegr.f` |
| `dev/validate_tgk.py` | NumPy check of the TGK qd recurrences and γ relation (no Fortran compiler here) | — |

## Representation switch

`dlar1v_tgk` / `dlarrf_tgk` take a leading `CHARACTER*1 REP`:
- `REP='L'` — `LDLᵀ` input; behaviour byte-for-byte identical to the `stegr_ID` original.
  Arrays `D, L, LD, LLD` are the usual factored representation.
- `REP='T'` — TGK / tridiagonal input. `D` = diagonal (all 0 for `T_GK`, kept general),
  `L` = off-diagonals `β` (length N−1). `LD`, `LLD` are **not referenced**.

This keeps the argument lists drop-in compatible and lets the same routine serve the root
(`'T'`) and, if ever wanted, ordinary `LDLᵀ` nodes (`'L'`).

## Key derivation: γ_k for the TGK (REP='T') path

Twisted factorization element (thesis eq. 3.1.12): `γ_k = D₊(k) + D₋(k) − J_kk`, where
`J = M − σI`, so `J_kk = D(k) − σ` (and `= −σ` for `T_GK`).

The original `dlar1v.f` selects the twist index from `WORK(INDS+k-1) + WORK(INDP+k-1) = γ_k`
and reuses those `WORK` slots for back-substitution. To keep the selection and
back-substitution code **unchanged**, the `REP='T'` transforms store:

```
stationary  (i = B1..R2):  WORK(INDS+i-1) = D₊(i)                 ! D₊(B1)=D(B1)-σ ; D₊(i+1)=D(i+1)-σ - β_i·L₊(i)
                           WORK(i)       = L₊(i) = β_i / D₊(i)    ! upward back-substitution
progressive (i = R1..BN):  WORK(INDP+i-1) = D₋(i) − (D(i) − σ)    ! ⇒ sum gives γ_i exactly
                           WORK(INDUMN+i)= U₋(i) = β_i / D₋(i+1)  ! downward back-substitution
```

Then `WORK(INDS+k-1)+WORK(INDP+k-1) = D₊(k)+D₋(k) − (D(k)−σ) = γ_k`, so the existing
argmin-|γ| selection and the twisted solve carry over verbatim. For `T_GK` (`D≡0`) this is
`γ_k = D₊(k)+D₋(k)+σ`.

Zero pivots (`D₊(i)=0` or `D₋(i)=0`) propagate ∞/NaN; the slow re-start paths mirror the
originals with `β_i²` in place of `LLD(i)`.
