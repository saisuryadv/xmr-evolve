#!/bin/sh
# Build the TGK-rooted bidiagonal-SVD code and run the self-contained
# benchmarks.  Requires gfortran and a LAPACK/BLAS.
#
# Set the LAPACK/BLAS link flags for your system via $LAPACK, e.g.:
#   Linux / OpenBLAS:  LAPACK="-llapack -lblas"      ./run_tests.sh
#   macOS Accelerate:  LAPACK="-framework Accelerate" ./run_tests.sh
# NOTE: some older LAPACKs (incl. macOS Accelerate) have a DLASQ1 that
# fails (IINFO=2) on a few hard matrices; a modern LAPACK/OpenBLAS is
# recommended for full coverage.
set -e
LAPACK="${LAPACK:--llapack -lblas}"
mkdir -p build
echo "Compiling core objects (LAPACK flags: $LAPACK) ..."
gfortran -c -O2 -std=legacy -fno-automatic \
    dbdtgk.f dlar1v_tgk.f dlarrf_tgk.f dlarrv_tgk.f dbdsvdmr3.f \
    stegr_ID/dlarrb.f
gfortran -O2 -std=legacy            dev/test_svd.f       *.o $LAPACK -o build/test_svd
gfortran -O2 -std=legacy -fno-automatic dev/test_chol_big.f *.o $LAPACK -o build/test_chol_big
gfortran -O2 -std=legacy            dev/test_stcoll.f    *.o $LAPACK -o build/test_stcoll
rm -f *.o
echo
echo "==== Benchmark 1: random bidiagonals n=2..55 (compared to DGESVD) ===="
./build/test_svd
echo
echo "==== Benchmark 2: small glued-Wilkinson reproducers (strong-glue) ===="
echo "(finite, no NaN; orthogonality degraded -- documented floor)"
for m in W21x3_g1e+12 W21x4_g1e+12; do
    echo "-- $m --"
    ./build/test_chol_big dev/smallglue/$m.dat
done
echo
echo "For STCollection matrices (github.com/oamarques/STCollection):"
echo "    ./build/test_stcoll /path/to/B_xxxx.dat"
