      SUBROUTINE SLARRV( N, D, L, ISPLIT, M, W, IBLOCK, INDEXW, GERSCH,
     $                   TOL, Z, LDZ, ISUPPZ, WORK, IWORK, INFO )
*
*  -- LAPACK auxiliary routine (version *TBA*) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     November 11, 2003
*
*     .. Scalar Arguments ..
      INTEGER            INFO, LDZ, M, N
      REAL               TOL
*     ..
*     .. Array Arguments ..
      INTEGER            IBLOCK( * ), INDEXW( * ), ISPLIT( * ),
     $                   ISUPPZ( * ), IWORK( * )
      REAL               D( * ), GERSCH( * ), L( * ), W( * ), WORK( * ),
     $                   Z( LDZ, * )
*     ..
*
*  Purpose
*  =======
*
*  SLARRV computes the eigenvectors of the tridiagonal matrix
*  T = L D L^T given L, D and the eigenvalues of L D L^T.
*  The input eigenvalues should have high relative accuracy with
*  respect to the entries of L and D. The desired accuracy of the
*  eigenvectors can be specified by the input parameter TOL.
*
*  Arguments
*  =========
*
*  N       (input) INTEGER
*          The order of the matrix.  N >= 0.
*
*  D       (input/output) REAL array, dimension (N)
*          On entry, the N diagonal elements of the diagonal matrix D.
*          On exit, D may be overwritten.
*
*  L       (input/output) REAL array, dimension (N)
*          On entry, the (N-1) subdiagonal elements of the unit
*          bidiagonal matrix L are in elements 1 to N-1 of L. L(N) need
*          not be set on input, but is used internally as workspace.
*          On exit, L is overwritten.
*
*  ISPLIT  (input) INTEGER array, dimension (N)
*          The splitting points, at which T breaks up into blocks.
*          The first block consists of rows/columns 1 to
*          ISPLIT( 1 ), the second of rows/columns ISPLIT( 1 )+1
*          through ISPLIT( 2 ), etc.
*
*  TOL     (input) REAL
*          The absolute error tolerance for the eigenvectors.
*          The eigenvectors output have residual norms
*          bounded by TOL, and the dot products between different
*          eigenvectors are bounded by TOL. TOL must be at least
*          N*EPS*|T|, where EPS is the machine precision and |T| is
*          the 1-norm of the tridiagonal matrix.
*
*  M       (input) INTEGER
*          The total number of input eigenvalues.  0 <= M <= N.
*
*  W       (input) REAL array, dimension (N)
*          The first M elements of W contain the eigenvalues for
*          which eigenvectors are to be computed.  The eigenvalues
*          should be grouped by split-off block and ordered from
*          smallest to largest within the block ( The output array
*          W from SLARRE is expected here ).
*          Errors in W must be bounded by TOL (see above).
*
*  IBLOCK  (input) INTEGER array, dimension (N)
*          The indices of the blocks (submatrices) associated with the
*          corresponding eigenvalues in W; IBLOCK(i)=1 if eigenvalue
*          W(i) belongs to the first block from the top, =2 if W(i)
*          belongs to the second block, etc.
*
*  INDEXW  (input) INTEGER array, dimension (N)
*          The indices of the eigenvalues within each block (submatrix);
*          for example, INDEXW(i)= 10 and IBLOCK(i)=2 imply that the
*          i-th eigenvalue W(i) is the 10-th eigenvalue in the second block.
*
*  GERSCH  (input) REAL array, dimension (2*N)
*          The N Gerschgorin intervals (the i-th Gerschgorin interval
*          is (GERSCH(2*i-1), GERSCH(2*i)).
*
*  Z       (output) REAL array, dimension (LDZ, max(1,M) )
*          If INFO = 0, the first M columns of Z contain the
*          orthonormal eigenvectors of the matrix T
*          corresponding to the input eigenvalues, with the i-th
*          column of Z holding the eigenvector associated with W(i).
*          Note: the user must ensure that at least max(1,M) columns are
*          supplied in the array Z.
*
*  LDZ     (input) INTEGER
*          The leading dimension of the array Z.  LDZ >= 1, and if
*          JOBZ = 'V', LDZ >= max(1,N).
*
*  ISUPPZ  (output) INTEGER ARRAY, dimension ( 2*max(1,M) )
*          The support of the eigenvectors in Z, i.e., the indices
*          indicating the nonzero elements in Z. The I-th eigenvector
*          is nonzero only in elements ISUPPZ( 2*I-1 ) through
*          ISUPPZ( 2*I ).
*
*  WORK    (workspace) REAL array, dimension (13*N)
*
*  IWORK   (workspace) INTEGER array, dimension (6*N)
*
*  INFO    (output) INTEGER
*          = 0:  successful exit
*          > 0:  if INFO = 1, internal error in SLARRB
*                if INFO = 2, internal error in SSTEIN
*
*  Further Details
*  ===============
*
*  Based on contributions by
*     Inderjit Dhillon, University of Texas, Austin, USA
*     Osni Marques, LBNL/NERSC, USA
*
*  =====================================================================
*
*     .. Parameters ..
      INTEGER            MAXITR, MGSSIZ
      PARAMETER          ( MAXITR = 8, MGSSIZ = 1 )
      REAL               ZERO, ONE, FOUR, RELTHR
      PARAMETER          ( ZERO = 0.0E0, ONE = 1.0E0, FOUR = 4.0E0,
     $                     RELTHR = 1.0E-3 )
*     ..
*     .. Local Scalars ..
      LOGICAL            NOMGS
      INTEGER            I, IBEGIN, IEND, IINDC1, IINDC2, IINDR, IINDWK,
     $                   IINFO, IM, IN, INDERR, INDGAP, INDLD, INDLLD,
     $                   INDWRK, ITER, ITMP1, ITMP2, J, JBLK, K, KTOT,
     $                   NCLUS, NDEPTH, NDONE, NEWCLS, NEWFRS, NEWFTT,
     $                   NEWLST, NEWSIZ, OLDCLS, OLDFST, OLDIEN, OLDLST,
     $                   OLDNCL, P, PARITY, Q, WBEGIN, WEND, ZFROM, ZTO
      REAL               EPS, GAP, LAMBDA, MGSTOL, MINGMA, MINRGP,
     $                   NRMINV, RELGAP, RELTOL, RESID, RQCORR, SIGMA,
     $                   TMP, ZTZ
*     ..
*     .. External Functions ..
      REAL               SDOT, SLAMCH, SNRM2
      EXTERNAL           SDOT, SLAMCH, SNRM2
*     ..
*     .. External Subroutines ..
      EXTERNAL           SAXPY, SCOPY, SLAR1V, SLARRB, SLARRF, SLASET,
     $                   SSCAL, SSTEIN
*     ..
*     .. Intrinsic Functions ..
      INTRINSIC          ABS, MAX, MIN, REAL, SQRT
*     ..
*     .. Local Arrays ..
      INTEGER            TEMP( 1 )
*     ..
*     .. Executable Statements ..
*     ..
      INDERR = N
      INDLD = 2*N
      INDLLD = 3*N
      INDGAP = 4*N
      INDWRK = 5*N + 1
*
      IINDR = N
      IINDC1 = 2*N
      IINDC2 = 3*N
      IINDWK = 4*N + 1
*
      EPS = SLAMCH( 'Precision' )
*
      DO 10 I = 1, 2*N
         IWORK( I ) = 0
   10 CONTINUE
      CALL SLASET( 'Full', N, N, ZERO, ZERO, Z, LDZ )
      MGSTOL = 100.0E0*EPS
*
      IBEGIN = 1
      WBEGIN = 1
      DO 170 JBLK = 1, IBLOCK( M )
         IEND = ISPLIT( JBLK )
*
*        Find the eigenvectors of the submatrix indexed IBEGIN
*        through IEND.
*
         WEND = WBEGIN - 1
 171     CONTINUE
         IF( WEND.LT.M ) THEN
            IF( IBLOCK( WEND+1 ).EQ.JBLK ) THEN
               WEND = WEND + 1
               GO TO 171
            END IF
         END IF
         IF( WEND.LT.WBEGIN ) THEN
            IBEGIN = IEND + 1
            GO TO 170
         END IF
*
         IF( IBEGIN.EQ.IEND ) THEN
            Z( IBEGIN, WBEGIN ) = ONE
            ISUPPZ( 2*WBEGIN-1 ) = IBEGIN
            ISUPPZ( 2*WBEGIN ) = IBEGIN
            IBEGIN = IEND + 1
            WBEGIN = WEND + 1
            GO TO 170
         END IF
         OLDIEN = IBEGIN - 1
         IN = IEND - OLDIEN
         RELTOL = MIN( RELTHR, ONE / REAL( IN ) )
         IM = WEND - WBEGIN + 1
         CALL SCOPY( IM, W( WBEGIN ), 1, WORK, 1 )
         DO 30 I = 1, IM - 1
            WORK( INDERR+I ) = EPS*ABS( WORK( I ) )
            WORK( INDGAP+I ) = WORK( I+1 ) - WORK( I )
   30    CONTINUE
         WORK( INDERR+IM ) = EPS*ABS( WORK( IM ) )
         WORK( INDGAP+IM ) = MAX( ABS( WORK( IM ) ), EPS )
         NDONE = 0
*
         NDEPTH = 0
         PARITY = 1
         NCLUS = 1
         IWORK( IINDC1+1 ) = 1
         IWORK( IINDC1+2 ) = IM
*
*        While( NDONE.LT.IM ) do
*
   40    CONTINUE
         IF( NDONE.LT.IM ) THEN
            OLDNCL = NCLUS
            NCLUS = 0
            PARITY = 1 - PARITY
            IF( PARITY.EQ.0 ) THEN
               OLDCLS = IINDC1
               NEWCLS = IINDC2
            ELSE
               OLDCLS = IINDC2
               NEWCLS = IINDC1
            END IF
            DO 150 I = 1, OLDNCL
*
*              If NDEPTH > 1, retrieve the relatively robust
*              representation (RRR) and perform limited bisection
*              (if necessary) to get approximate eigenvalues.
*
               J = OLDCLS + 2*I
               OLDFST = IWORK( J-1 )
               OLDLST = IWORK( J )
               IF( NDEPTH.GT.0 ) THEN
                  J = WBEGIN + OLDFST - 1
                  CALL SCOPY( IN, Z( IBEGIN, J ), 1, D( IBEGIN ), 1 )
                  CALL SCOPY( IN-1, Z( IBEGIN, J+1 ), 1, L( IBEGIN ),
     $               1 )
                  CALL SLASET( 'Full', IN, 2, ZERO, ZERO,
     $                               Z( IBEGIN, J ), LDZ )
               END IF
               K = IBEGIN
               DO 50 J = 1, IN - 1
                  TMP = D( K )*L( K )
                  WORK( INDLD+J ) = TMP
                  WORK( INDLLD+J ) = TMP*L( K )
                  K = K + 1
   50          CONTINUE
               IF( NDEPTH.GT.0 ) THEN
*
*  The way OLDFST and OLDLST are used in the following is a problem
*  when eigenvalues in a range are desired!
*
                  P = INDEXW( WBEGIN-1+OLDFST )
                  Q = INDEXW( WBEGIN-1+OLDLST )
                  CALL SLARRB( IN, D( IBEGIN ), L( IBEGIN ),
     $                         WORK( INDLD+1 ), WORK( INDLLD+1 ),
     $                         P, Q, RELTOL, FOUR*EPS, P-OLDFST, WORK,
     $                         WORK( INDGAP+1 ), WORK( INDERR+1 ),
     $                         WORK( INDWRK+IN ), IWORK( IINDWK ),
     $                         IINFO )
               END IF
*
*              Classify eigenvalues of the current representation (RRR)
*              as (i) isolated, or (ii) clustered.
*
               NEWFRS = OLDFST
               DO 140 J = OLDFST, OLDLST
                  IF( J.EQ.OLDLST .OR. WORK( INDGAP+J ).GE.RELTOL*
     $                ABS( WORK( J ) ) ) THEN
                     NEWLST = J
                  ELSE
*
*                    continue (to the next loop)
*
                     RELGAP = WORK( INDGAP+J ) / ABS( WORK( J ) )
                     IF( J.EQ.NEWFRS ) THEN
                        MINRGP = RELGAP
                     ELSE
                        MINRGP = MIN( MINRGP, RELGAP )
                     END IF
                     GO TO 140
                  END IF
                  NEWSIZ = NEWLST - NEWFRS + 1
                  NEWFTT = WBEGIN + NEWFRS - 1
                  NOMGS = NEWSIZ.EQ.1 .OR. NEWSIZ.GT.MGSSIZ .OR.
     $                    MINRGP.LT.MGSTOL
                  IF( NEWSIZ.GT.1 .AND. NOMGS ) THEN
*
*                    Find a new L D L^T representation if the cluster
*                    size is larger than MGSSIZ or the minimum
*                    relative gap within the cluster is too small.
*
                     CALL SLARRF( IN, D( IBEGIN ), L( IBEGIN ),
     $                            WORK( INDLD+1 ), WORK( INDLLD+1 ),
     $                            NEWFRS, NEWLST, WORK, SIGMA,
     $                            Z( IBEGIN, NEWFTT ),
     $                            Z( IBEGIN, NEWFTT+1 ),
     $                            WORK( INDWRK ), INFO )
                     IF( INFO.EQ.0 ) THEN
                        TMP = EPS*( ABS( SIGMA ) )
                        DO 51 K = NEWFRS, NEWLST
                           WORK( K ) = WORK( K ) - SIGMA
                           WORK( INDGAP+K ) = MAX( WORK( INDGAP+K ),
     $                                        TMP )
                           WORK( INDERR+K ) = WORK( INDERR+K ) + TMP
   51                   CONTINUE
                        NCLUS = NCLUS + 1
                        K = NEWCLS + 2*NCLUS
                        IWORK( K-1 ) = NEWFRS
                        IWORK( K ) = NEWLST
                     ELSE
                        INFO = 0
                        IF( MINRGP.GE.MGSTOL ) THEN
                           NOMGS = .FALSE.
                        ELSE
*                        
*                          Call SSTEIN to process this tight cluster.
*                          This happens only if MINRGP <= MGSTOL
*                          and SLARRF returns INFO = 1. The latter
*                          means that a new RRR to "break" the
*                          cluster could not be found.
*
                           WORK( INDWRK ) = D( IBEGIN )
                           DO 60 K = 1, IN - 1
                              WORK( INDWRK+K ) = D( IBEGIN+K ) +
     $                                           WORK( INDLLD+K )
   60                      CONTINUE
                           DO 70 K = 1, NEWSIZ
                              IWORK( IINDWK+K-1 ) = 1
   70                      CONTINUE
                           DO 80 K = NEWFRS, NEWLST
                              ISUPPZ( 2*( OLDIEN+K )-1 ) = 1
                              ISUPPZ( 2*( OLDIEN+K ) ) = IN
   80                      CONTINUE
                           TEMP( 1 ) = IN
                           CALL SSTEIN( IN, WORK( INDWRK ),
     $                                  WORK( INDLD+1 ), NEWSIZ,
     $                                  WORK( NEWFRS ),
     $                                  IWORK( IINDWK ), TEMP( 1 ),
     $                                  Z( IBEGIN, NEWFTT ), LDZ,
     $                                  WORK( INDWRK+IN ),
     $                                  IWORK( IINDWK+IN ),
     $                                  IWORK( IINDWK+2*IN ), IINFO )
                           IF( IINFO.NE.0 ) THEN
                              INFO = 2
                              RETURN
                           END IF
                           NDONE = NDONE + NEWSIZ
                        END IF
                     END IF
                  ELSE
                     KTOT = NEWFTT
                     DO 100 K = NEWFRS, NEWLST
                        ITER = 0
   90                   CONTINUE
                        LAMBDA = WORK( K )
*
*                       Given LAMBDA, compute the eigenvector.
*
                        CALL SLAR1V( IN, 1, IN, LAMBDA, D( IBEGIN ),
     $                               L( IBEGIN ), WORK( INDLD+1 ),
     $                               WORK( INDLLD+1 ), W( WBEGIN+K-1 ),
     $                               GERSCH( 2*OLDIEN+1 ),
     $                               Z( IBEGIN, KTOT ), ZTZ, MINGMA,
     $                               IWORK( IINDR+KTOT ),
     $                               ISUPPZ( 2*KTOT-1 ),
     $                               WORK( INDWRK ) )
                        TMP = ONE / ZTZ
                        NRMINV = SQRT( TMP )
                        RESID = ABS( MINGMA )*NRMINV
                        RQCORR = MINGMA*TMP
                        IF( K.EQ.IN ) THEN
                           GAP = WORK( INDGAP+K-1 )
                        ELSE IF( K.EQ.1 ) THEN
                           GAP = WORK( INDGAP+K )
                        ELSE
                           GAP = MIN( WORK( INDGAP+K-1 ),
     $                           WORK( INDGAP+K ) )
                        END IF
                        ITER = ITER + 1
                        IF( RESID.GT.TOL*GAP .AND. ABS( RQCORR ).GT.
     $                      FOUR*EPS*ABS( LAMBDA ) ) THEN
                           WORK( K ) = LAMBDA + RQCORR
                           IF( ITER.LT.MAXITR ) THEN
                              GO TO 90
                           END IF
                        END IF
                        IWORK( KTOT ) = 1
                        IF( NEWSIZ.EQ.1 )
     $                     NDONE = NDONE + 1
                        ZFROM = ISUPPZ( 2*KTOT-1 )
                        ZTO = ISUPPZ( 2*KTOT )
                        CALL SSCAL( ZTO-ZFROM+1, NRMINV,
     $                          Z( IBEGIN+ZFROM-1, KTOT ), 1 )
                        KTOT = KTOT + 1
  100                CONTINUE
                     IF( NEWSIZ.GT.1 ) THEN
                        ITMP1 = ISUPPZ( 2*NEWFTT-1 )
                        ITMP2 = ISUPPZ( 2*NEWFTT )
                        KTOT = OLDIEN + NEWLST
                        DO 120 P = NEWFTT + 1, KTOT
                           DO 110 Q = NEWFTT, P - 1
                              TMP = -SDOT( IN, Z( IBEGIN, P ), 1,
     $                               Z( IBEGIN, Q ), 1 )
                              CALL SAXPY( IN, TMP, Z( IBEGIN, Q ), 1,
     $                                    Z( IBEGIN, P ), 1 )
  110                      CONTINUE
                           TMP = ONE / SNRM2( IN, Z( IBEGIN, P ), 1 )
                           CALL SSCAL( IN, TMP, Z( IBEGIN, P ), 1 )
                           ITMP1 = MIN( ITMP1, ISUPPZ( 2*P-1 ) )
                           ITMP2 = MAX( ITMP2, ISUPPZ( 2*P ) )
  120                   CONTINUE
                        DO 130 P = NEWFTT, KTOT
                           ISUPPZ( 2*P-1 ) = ITMP1
                           ISUPPZ( 2*P ) = ITMP2
  130                   CONTINUE
                        NDONE = NDONE + NEWSIZ
                     END IF
                  END IF
                  NEWFRS = J + 1
  140          CONTINUE
  150       CONTINUE
            NDEPTH = NDEPTH + 1
            GO TO 40
         END IF
         J = 2*WBEGIN
         DO 160 I = WBEGIN, WEND
            ISUPPZ( J-1 ) = ISUPPZ( J-1 ) + OLDIEN
            ISUPPZ( J ) = ISUPPZ( J ) + OLDIEN
            J = J + 2
  160    CONTINUE
         IBEGIN = IEND + 1
         WBEGIN = WEND + 1
  170 CONTINUE
*
      RETURN
*
*     End of SLARRV
*
      END
